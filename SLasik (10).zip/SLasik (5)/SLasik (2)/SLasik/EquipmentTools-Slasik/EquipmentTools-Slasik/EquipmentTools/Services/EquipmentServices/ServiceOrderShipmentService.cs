﻿
using EquipmentTools.Data;
using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;

namespace EquipmentTools.Services.EquipmentServices;

public class ServiceOrderShipmentService
{
    private static readonly List<long> CreatedServiceStatusId = new List<long> { 1, 2 };
    private readonly IDbContextFactory<EquipmentContext> dbContextFactory;

    public ServiceOrderShipmentService(IDbContextFactory<EquipmentContext> dbContextFactory)
    {
        this.dbContextFactory = dbContextFactory;
    }

    public async Task<List<ServiceOrder>> GetCreatedOrdersAsync()
    {
        await using var context = await dbContextFactory.CreateDbContextAsync();

        var groupedUnitIds = context.ServiceOrderShipments
            .Select(shipment => shipment.ServiceOrderUnitsId);

        var orders = await context.ServiceOrders
            .AsNoTracking()
            .Include(order => order.ServiceOrderStatuses)
            .Include(order => order.ServiceOrderUnits)
                .ThenInclude(unit => unit.Unit)
                    .ThenInclude(unit => unit.Model)
                        .ThenInclude(model => model.TypeNavigation)
            .Include(order => order.ServiceOrderUnits)
                .ThenInclude(unit => unit.DamageTypes)
            .Where(order => order.ServiceOrderUnits
                .All(unit => !groupedUnitIds.Contains(unit.ServiceOrderUnitsID)))
            .Where(order => order.ServiceOrderStatuses
                .OrderByDescending(status => status.ServiceOrderStatusesID)
                .Select(status => (long?)status.StatusID)
                .Take(1)
                .Any(statusId => statusId.HasValue && CreatedServiceStatusId.Contains(statusId.Value)))
            .OrderByDescending(order => order.ServiceOrdersID)
            .ToListAsync();

        return orders;
    }

    public async Task<long> CreateShipmentAsync(IEnumerable<long> serviceOrderIds)
    {
        var orderIds = serviceOrderIds.Distinct().ToList();

        if (orderIds.Count < 2)
            throw new InvalidOperationException("Выберите минимум две заявки.");

        await using var context = await dbContextFactory.CreateDbContextAsync();

        var orders = await context.ServiceOrders
            .Where(order => orderIds.Contains(order.ServiceOrdersID))
            .Include(order => order.ServiceOrderStatuses)
            .Include(order => order.ServiceOrderUnits)
            .ToListAsync();

        if (orders.Count != orderIds.Count)
            throw new InvalidOperationException("Часть выбранных заявок больше не существует.");

        if (orders.Any(order => !CreatedServiceStatusId.Contains(
            order.ServiceOrderStatuses
                .OrderByDescending(status => status.ServiceOrderStatusesID)
                .FirstOrDefault()?.StatusID ?? 0)))
        {
            throw new InvalidOperationException("Объединять можно только заявки с актуальным статусом «Создано».");
        }

        var serviceOrderUnitIds = orders
            .SelectMany(order => order.ServiceOrderUnits)
            .Select(unit => unit.ServiceOrderUnitsID)
            .ToList();

        if (serviceOrderUnitIds.Count == 0)
            throw new InvalidOperationException("В выбранных заявках нет оборудования.");

        var alreadyGrouped = await context.ServiceOrderShipments
            .AnyAsync(shipment => serviceOrderUnitIds.Contains(shipment.ServiceOrderUnitsId));

        if (alreadyGrouped)
            throw new InvalidOperationException("Одна или несколько единиц оборудования уже входят в объединённую заявку.");

        // Создаём строки объединения.
        // ID первой строки становится общим ID объединённой заявки.
        var shipments = serviceOrderUnitIds.Select(unitId => new ServiceOrderShipment
        {
            ShipmentGroupId = 0,
            ServiceOrderUnitsId = unitId,
            ServiceStatusesId = CreatedServiceStatusId[0]
        }).ToList();

        context.ServiceOrderShipments.AddRange(shipments);
        await context.SaveChangesAsync();

        var shipmentGroupId = shipments[0].ServiceOrderShipmentId;

        foreach (var shipment in shipments)
            shipment.ShipmentGroupId = shipmentGroupId;

        await context.SaveChangesAsync();

        return shipmentGroupId;
    }

    // ДОБАВЛЕНИЕ ЦЕЛОЙ ИСХОДНОЙ ЗАЯВКИ В СУЩЕСТВУЮЩЕЕ ОБЪЕДИНЕНИЕ
    public async Task AddOrderToShipmentAsync(long shipmentGroupId, long serviceOrderId)
    {
        await using var context = await dbContextFactory.CreateDbContextAsync();

        // Проверяем, что объединение существует, и получаем его текущий статус.
        var groupStatusId = await context.ServiceOrderShipments
            .Where(shipment => shipment.ShipmentGroupId == shipmentGroupId)
            .Select(shipment => (long?)shipment.ServiceStatusesId)
            .FirstOrDefaultAsync();

        if (!groupStatusId.HasValue)
            throw new InvalidOperationException("Объединённая заявка не найдена.");

        // Загружаем исходную заявку вместе со всем её оборудованием и статусами.
        var order = await context.ServiceOrders
            .Include(item => item.ServiceOrderStatuses)
            .Include(item => item.ServiceOrderUnits)
            .FirstOrDefaultAsync(item => item.ServiceOrdersID == serviceOrderId);

        if (order == null)
            throw new InvalidOperationException("Выбранная заявка не найдена.");

        // Проверяем актуальный статус исходной заявки.
        var currentStatusId = order.ServiceOrderStatuses
            .OrderByDescending(status => status.ServiceOrderStatusesID)
            .Select(status => (long?)status.StatusID)
            .FirstOrDefault();

        if (!currentStatusId.HasValue ||
            !CreatedServiceStatusId.Contains(currentStatusId.Value))
        {
            throw new InvalidOperationException(
                "Добавлять можно только заявки с актуальным статусом «Создано».");
        }

        // Получаем ID всего оборудования выбранной заявки.
        var unitIds = order.ServiceOrderUnits
            .Select(unit => unit.ServiceOrderUnitsID)
            .Distinct()
            .ToList();

        if (unitIds.Count == 0)
            throw new InvalidOperationException("В выбранной заявке нет оборудования.");

        // Проверяем, что оборудование ещё не находится ни в одном объединении.
        var alreadyGrouped = await context.ServiceOrderShipments
            .AnyAsync(shipment => unitIds.Contains(shipment.ServiceOrderUnitsId));

        if (alreadyGrouped)
        {
            throw new InvalidOperationException(
                "Одна или несколько единиц оборудования уже входят в объединённую заявку.");
        }

        // Добавляем всё оборудование в существующую группу.
        var shipments = unitIds.Select(unitId => new ServiceOrderShipment
        {
            ShipmentGroupId = shipmentGroupId,
            ServiceOrderUnitsId = unitId,
            ServiceStatusesId = groupStatusId.Value
        });

        context.ServiceOrderShipments.AddRange(shipments);

        await context.SaveChangesAsync();
    }

    // УДАЛЕНИЕ ОБОРУДОВАНИЯ ТОЛЬКО ИЗ ОБЪЕДИНЕНИЯ
    public async Task RemoveEquipmentFromShipmentAsync(
        long shipmentGroupId,
        long serviceOrderUnitsId)
    {
        await using var context = await dbContextFactory.CreateDbContextAsync();

        var shipment = await context.ServiceOrderShipments
            .FirstOrDefaultAsync(item =>
                item.ShipmentGroupId == shipmentGroupId &&
                item.ServiceOrderUnitsId == serviceOrderUnitsId);

        if (shipment == null)
            throw new InvalidOperationException(
                "Оборудование не найдено в данной объединённой заявке.");

        // Не позволяем удалить последнюю запись, иначе группа перестанет загружаться.
        var equipmentCount = await context.ServiceOrderShipments
            .CountAsync(item => item.ShipmentGroupId == shipmentGroupId);

        if (equipmentCount <= 1)
            throw new InvalidOperationException(
                "Нельзя удалить последнее оборудование из объединённой заявки.");

        // Удаляем только связь с объединением.
        // Исходная заявка и само оборудование остаются в базе.
        context.ServiceOrderShipments.Remove(shipment);

        await context.SaveChangesAsync();
    }

    public async Task<ServiceOrderShipmentGroup?> GetShipmentGroupAsync(long shipmentGroupId)
    {
        await using var context = await dbContextFactory.CreateDbContextAsync();

        var shipmentItems = await context.ServiceOrderShipments
            .AsNoTracking()
            .Where(shipment => shipment.ShipmentGroupId == shipmentGroupId)
            .Include(shipment => shipment.ServiceStatuses)
            .Include(shipment => shipment.ServiceOrderUnit)
                .ThenInclude(orderUnit => orderUnit.ServiceOrders)
            .Include(shipment => shipment.ServiceOrderUnit)
                .ThenInclude(orderUnit => orderUnit.DamageTypes)
            .Include(shipment => shipment.ServiceOrderUnit)
                .ThenInclude(orderUnit => orderUnit.Unit)
                    .ThenInclude(unit => unit.Model)
                        .ThenInclude(model => model.TypeNavigation)
            .ToListAsync();

        if (shipmentItems.Count == 0)
            return null;

        return new ServiceOrderShipmentGroup
        {
            ShipmentGroupId = shipmentGroupId,
            ServiceOrderIds = shipmentItems
                .Select(item => item.ServiceOrderUnit.ServiceOrdersID)
                .Where(orderId => orderId.HasValue)
                .Select(orderId => orderId!.Value)
                .Distinct()
                .OrderBy(orderId => orderId)
                .ToList(),
            FirstApplicationDate = shipmentItems
                .Select(item => item.ServiceOrderUnit.ServiceOrders?.ApplicationDate)
                .Where(date => date.HasValue)
                .Select(date => date!.Value)
                .DefaultIfEmpty()
                .Min(),
            StatusName = shipmentItems
                .Select(item => item.ServiceStatuses?.ServiceStatusName)
                .FirstOrDefault(),
            ServiceOrderUnits = shipmentItems
                .Select(item => item.ServiceOrderUnit)
                .Where(orderUnit => orderUnit is not null)
                .ToList()
        };
    }

    public async Task UpdateShipmentStatusAsync(long shipmentGroupId, long newStatusId)
    {
        await using var context = await dbContextFactory.CreateDbContextAsync();

        var items = await context.ServiceOrderShipments
            .Where(s => s.ShipmentGroupId == shipmentGroupId)
            .ToListAsync();

        foreach (var item in items)
        {
            item.ServiceStatusesId = newStatusId;
        }

        await context.SaveChangesAsync();
    }
    // УДАЛЕНИЕ ИСХОДНОЙ ЗАЯВКИ ТОЛЬКО ИЗ ОБЪЕДИНЕНИЯ
    public async Task RemoveOrderFromShipmentAsync(
        long shipmentGroupId,
        long serviceOrderId)
    {
        await using var context = await dbContextFactory.CreateDbContextAsync();

        // Получаем все записи оборудования текущего объединения.
        var groupItems = await context.ServiceOrderShipments
            .Where(item => item.ShipmentGroupId == shipmentGroupId)
            .Include(item => item.ServiceOrderUnit)
            .ToListAsync();

        if (groupItems.Count == 0)
            throw new InvalidOperationException(
                "Объединённая заявка не найдена.");

        // Находим оборудование выбранной исходной заявки,
        // которое сейчас входит в это объединение.
        var orderItems = groupItems
            .Where(item =>
                item.ServiceOrderUnit?.ServiceOrdersID == serviceOrderId)
            .ToList();

        if (orderItems.Count == 0)
            throw new InvalidOperationException(
                "Выбранная заявка не найдена в этом объединении.");

        // Считаем количество разных исходных заявок в объединении.
        var orderCount = groupItems
            .Select(item => item.ServiceOrderUnit?.ServiceOrdersID)
            .Where(orderId => orderId.HasValue)
            .Select(orderId => orderId!.Value)
            .Distinct()
            .Count();

        // Не разрешаем удалить последнюю исходную заявку.
        if (orderCount <= 1)
            throw new InvalidOperationException(
                "Нельзя удалить последнюю заявку из объединения.");

        // Удаляем только связи оборудования с объединением.
        // Исходная заявка и само оборудование остаются в базе.
        context.ServiceOrderShipments.RemoveRange(orderItems);

        await context.SaveChangesAsync();
    }
}
