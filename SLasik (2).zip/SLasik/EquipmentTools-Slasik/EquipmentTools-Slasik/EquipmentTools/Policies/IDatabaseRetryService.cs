﻿namespace WMSLoginsAccounting.Policies
{    public interface IDatabaseRetryService
    {
        Task ExecuteWithRetryAsync(Func<Task> action);
        Task ExecutePipelineWithRetryAsync(Func<Task> action);
    }
}
