﻿using FirebirdSql.Data.FirebirdClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Polly;
using System;
using System.Data.SqlClient;
using WMSLoginsAccounting.Options;

namespace WMSLoginsAccounting.Policies
{
    public class DatabaseRetryService : IDatabaseRetryService
    {
        private IAsyncPolicy _retryPolicy;

        private ResiliencePipeline pipeline;

        private readonly IOptions<DatabaseReconnectSettings> _databaseReconnectSettings;
        private readonly string _logFilePath = @"C:\Logs\ReconnectLog.txt";

        private readonly ILogger<DatabaseRetryService> _logger;

        public DatabaseRetryService(IOptions<DatabaseReconnectSettings> settings, ILogger<DatabaseRetryService> logger)
        {
            _logger = logger;
            _databaseReconnectSettings = settings;

            InitNew();
        }

        private void InitNew()
        {
            pipeline = new ResiliencePipelineBuilder()
                .AddRetry(new Polly.Retry.RetryStrategyOptions()
                {
                    ShouldHandle = new PredicateBuilder().Handle<Exception>(),
                    Delay = TimeSpan.FromSeconds(_databaseReconnectSettings.Value.RetryWaitPeriodInSeconds),
                    MaxRetryAttempts = _databaseReconnectSettings.Value.RetryCount,
                    BackoffType = DelayBackoffType.Constant, 
                    OnRetry = args =>
                    {
                        _logger.LogWarning($"Connection lost, retry attempt {args.AttemptNumber} at {DateTime.Now} . Exception Message: {args.Outcome.Exception}" + Environment.NewLine);
                        return default;
                    }
                })
                .Build();
        }

        public async Task ExecuteWithRetryAsync(Func<Task> action)
        {
            var context = new Context();

            int attempt = 0;
            await _retryPolicy.ExecuteAsync(async (ctx) =>
            {
                attempt++;
                await action();
            }, context);
            _logger.LogInformation($"Connection successfully reconnected at attempt {attempt} at {DateTime.Now}" + Environment.NewLine);

        }
        public async Task ExecutePipelineWithRetryAsync(Func<Task> action)
        {
            //var context = ResilienceContextPool.Shared.Get();

            int attempt = 0;
            await pipeline.ExecuteAsync(static async (ctx,a) =>
            {
                ctx.attempt++;
                await ctx.action();
            },(attempt, action), CancellationToken.None);
            if(attempt > 0) _logger.LogInformation($"Connection successfully reconnected at attempt {attempt} at {DateTime.Now}" + Environment.NewLine);

        }

    }
}
