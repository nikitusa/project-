using Coravel.Invocable;
using EquipmentTools.Services;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.EntityFrameworkCore;
using EquipmentTools.Data;
using EquipmentTools.Services.EquipmentSerices;
using System.ComponentModel.DataAnnotations;
using WMSLoginsAccounting.Models.TssPersonnelModel;
using WMSLoginsAccounting.Services.PersonelDataService;
using Microsoft.AspNetCore.Mvc;
using EquipmentTools.Models.EquipmentContext;
using EquipmentTools.Services.EquipmentServices;

namespace EquipmentTools.Schedulling
{
    public class SetToolsIDStatusInvocable : IInvocable
    {
        private ToolsIDService ToolsIDService { get; }
        private ILogger<SetToolsIDStatusInvocable> Logger { get; }
        private EquipStatusChangesService EquipStatusChangesService { get; }
        public AllEmployeesDBService AllEmployeesDBService { get; }
        private PersonelService PersonelService { get; }
        public BadgeBlockingService BadgeBlockingService { get; }
        public InventoryMembersService InventoryMembersService { get; }
        public InventoryUnitsService InventoryUnitsService { get; }
        public EmployeeBadgesService EmployeeBadgesService { get; }
        private PersonnelModel PersonnelModel { get; }

        public async Task Invoke()
        {
            try
            {
                var equipmentMapping = await ToolsIDService.GetAllToolsIDStatuses();
                var toolsIDDevices = await ToolsIDService.GetToolsIDEquipmentAsync();
                var employeesList = await ToolsIDService.GetEmployees();

                if (toolsIDDevices is null)
                {
                    Logger.LogWarning("Не удалось получить список оборудования ToolsID");
                    return;
                }

                if (employeesList is null)
                {
                    Logger.LogWarning("Не удалось получить список сотрудников ToolsID");
                    return;
                }

                await GetToolsIDStatusesAsync(toolsIDDevices, equipmentMapping, employeesList);

                Logger.LogInformation("Статусы шкафов ToolsID синхронизированы");
            }
            catch(Exception ex)
            {
                Logger.LogError(ex.ToString());
            }
        }

        public SetToolsIDStatusInvocable(ToolsIDService toolsIDService, ILogger<SetToolsIDStatusInvocable> logger, EquipStatusChangesService equipStatusChangesService, PersonelService personelService, 
            AllEmployeesDBService allEmployeesDBService, BadgeBlockingService badgeBlockingService, InventoryMembersService inventoryMembersService, InventoryUnitsService inventoryUnitsService, EmployeeBadgesService employeeBadgesService)
        {
            ToolsIDService = toolsIDService;
            Logger = logger;
            EquipStatusChangesService = equipStatusChangesService;
            PersonelService = personelService;
            AllEmployeesDBService = allEmployeesDBService;
            BadgeBlockingService = badgeBlockingService;
            InventoryMembersService = inventoryMembersService;
            InventoryUnitsService = inventoryUnitsService;
            EmployeeBadgesService = employeeBadgesService;
        }

        private async Task<List<EquipStatusChange>> GetToolsIDStatusesAsync(ToolsIDEquipmentDTO toolsIDEquipment, List<ToolsIDStatusMapping> equipmentMapping, List<ToolsIDEmployeeDto> employeesList)
        {
            List<EquipStatusChange> newStatuses = new List<EquipStatusChange>();
            var query = await EquipStatusChangesService.GetEquipStatusChangesQueryAsync(null);
            var query2 = query;


            var toolsIDEquip = toolsIDEquipment.ToolsIDData.Select(c => new    //берем из api данные об оборудовании
            {
                SerialNum = c.serial,
                NewStatus = equipmentMapping.FirstOrDefault(x => x.ToolsIDStatusID == c.new_state).EquipmentStatusID,
                ChangedTimestamp = c.changed_at,
                BadgeKey = (c.location?.Contains("метка: ") ?? false) ? (c.location?.Split("метка: ", 2).LastOrDefault()) : null
            }).ToList();

            var currentDBStatuses = await query.Where(c => toolsIDEquip.Select(x => x.SerialNum).Contains(c.Equip.SerialNumber)) // Берем последний статус для каждого оборудования
                .GroupBy(c => c.EquipID) // Группируем статусы по оборудованию
                .Select(c => new EquipStatusChange
                {
                    EquipStatusChangesID = c.Max(x => x.EquipStatusChangesID),
                    // берем последний Status Change ID

                })
                .Join(query2, c => c.EquipStatusChangesID, x => x.EquipStatusChangesID, (c, x) => new  // Соединяем чтобы взять доп даные
                {
                    EquipID = x.EquipID,
                    DateTimeChanged = x.DateTimeChanged,
                    Equip = x.Equip,
                    ClientActivityID = 59,
                    SerialNumber = x.Equip.SerialNumber,
                    Login = x.Login,
                    CurrentStatusID = x.CurrentStatusID
                })
                .ToListAsync();

            try
            {
                //var a = new DateTimeOffset(toolsIDEquip.First().ChangedTimestamp.GetValueOrDefault(), new TimeSpan(3, 0, 0));
                var filteredApiStatusList = (from sl in currentDBStatuses
                                             from t in toolsIDEquip.Where(c => c.SerialNum == sl.SerialNumber 
                                             && new DateTimeOffset(DateTime.SpecifyKind(c.ChangedTimestamp.GetValueOrDefault(), DateTimeKind.Local), new TimeSpan(3, 0, 0)).ToUniversalTime().DateTime > sl.DateTimeChanged                                             
                                             )
                                             select new
                                             {
                                                 EquipID = sl.EquipID,
                                                 DateTimeChanged = new DateTimeOffset(DateTime.SpecifyKind(t.ChangedTimestamp.GetValueOrDefault(), DateTimeKind.Local), new TimeSpan(3, 0, 0)).ToUniversalTime().DateTime,
                                                 //DateTimeChanged = t.ChangedTimestamp.GetValueOrDefault().ToUniversalTime(),
                                                 CurrentStatusID = t.NewStatus.GetValueOrDefault(),
                                                 BadgeKey = t.BadgeKey
                                             }).ToList();
                List<string> badges = toolsIDEquip?.Select(x => x.BadgeKey).Where(x => x != null).ToList();
                //IEnumerable<PersonnelModel> persEmpl = new List<PersonnelModel>();

                //if (badges?.Any() ?? false)
                //{
                //    persEmpl = await PersonelService.GetPersonnelEmplAsync(c => badges.Contains(c.PersonnelKey));
                //}

                var statusesWithPersonnelNumber = filteredApiStatusList.Join(employeesList, c => c.BadgeKey, x => x.BadgeKey, (c, x) => new EquipStatusChange  //Оборудование в работе с меткой сотрудника
                {
                    EquipID = c.EquipID,
                    DateTimeChanged = c.DateTimeChanged,
                    CurrentStatusID = c.CurrentStatusID,
                    Login = x.PersonnelNumber,
                    ClientActivityID = 59             // ИЗМЕНИТЬ АКТИВНОСТЬ ПОСЛЕ ЗАЛИВКИ БАЗЫ
                }).ToList();

                var workStatusList = statusesWithPersonnelNumber.Where(c => c.CurrentStatusID == 1).ToList();

                var passedEquipmentStatuses = (from tl in statusesWithPersonnelNumber     // Оборудование в работе уже у другого сотрудника
                                               from sl in currentDBStatuses.Where(c => c.EquipID == tl.EquipID && c.Login != tl.Login && c.CurrentStatusID == 1)
                                               select new EquipStatusChange
                                               {
                                                   EquipID = tl.EquipID,
                                                   DateTimeChanged = tl.DateTimeChanged,
                                                   CurrentStatusID = 2,
                                                   ClientActivityID = 59,
                                                   Login = sl.Login,
                                               }).ToList();

                var noBadgeOnBaseStatuses = filteredApiStatusList.Where(c => c.BadgeKey is null && c.CurrentStatusID == 2)
                    .Join(currentDBStatuses, c => c.EquipID, x => x.EquipID, (c, x) => new EquipStatusChange
                    {
                        EquipID = x.EquipID,
                        DateTimeChanged = c.DateTimeChanged,
                        CurrentStatusID = c.CurrentStatusID,
                        ClientActivityID = 59,
                        Login = x.Login,
                    }).ToList();

                var noBadgeStatuses = filteredApiStatusList.Where(c => c.BadgeKey is null && c.CurrentStatusID != 2)
                    .Join(currentDBStatuses, c => c.EquipID, x => x.EquipID, (c, x) => new EquipStatusChange
                    {
                        EquipID = x.EquipID,
                        DateTimeChanged = c.DateTimeChanged,
                        CurrentStatusID = c.CurrentStatusID,
                        ClientActivityID = 59,
                        Login = "TKV00-0000",
                    }).ToList();

                newStatuses.AddRange(passedEquipmentStatuses);
                newStatuses.AddRange(noBadgeStatuses);
                newStatuses.AddRange(noBadgeOnBaseStatuses);
                newStatuses.AddRange(workStatusList);

                //newStatuses = newStatuses.Where(c => new string[] { "TKV00-7370", "TKV00-9751", "TKV00-7637", "TKV00-7373", "TKV000841" }.Contains(c.Login)).ToList();

                if (newStatuses.Count > 0)
                {
                    await EquipStatusChangesService.SetEquipStasusListAsync(newStatuses);
                    //await BadgeBlockingService.SetBadgeBlockListAsync(newStatuses);
                }

                var memberQuery = await InventoryMembersService.GetInventoriesQuery(c => c.ClientID == 1);
                var member = await memberQuery.OrderBy(c=>c.InventoryMemberID).LastOrDefaultAsync();

                if (member != null && !member.Closed)
                {
                    var unitsToAdd = newStatuses.Where(c => c.CurrentStatusID != 4 && c.CurrentStatusID != 3).Select(c => c.EquipID).Distinct().ToList();
                    var inventoryUnits = await InventoryUnitsService.AddUnits(member.InventoryMemberID, unitsToAdd, 59);
                    if(inventoryUnits?.Count > 0) { Logger.LogInformation($"{inventoryUnits.Count} единиц оборудования из шкафов было добавлено в таблицу инвентаризации"); }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                Logger.LogError(ex.ToString());
            }




            return null;

        }

    }
}
