﻿using Coravel.Invocable;
using EquipmentTools.Models.EquipmentContext;
using EquipmentTools.Data;
using EquipmentTools.Services;
using EquipmentTools.Services.EquipmentSerices;
using Google.Apis.Services;
using Google.Apis.Sheets.v4;
using HR_Transfers_WebAPI.Google;
using HR_Transfers_WebAPI.Services.GoogleSheets;
using Microsoft.EntityFrameworkCore;
using WMSLoginsAccounting.Services.PersonelDataService;
using static EquipmentTools.Data.EquipmentLoginsBlocked;

namespace EquipmentTools.Schedulling
{
    public class LoginsBlockedGoogleInvocable : IInvocable
    {
    
        public LoginsBlockedGoogleInvocable(EquipmentUnitsService equipmentUnitsService, AllEmployeesDBService allEmployeesDBService,EquipStatusChangesService equipStatusChangesService,PersonelService personelService, IServiceProvider provider, ILogger<LoginsBlockedGoogleInvocable> logger) 
        {
            EquipmentUnitsService = equipmentUnitsService;
            AllEmployeesDBService = allEmployeesDBService;
            EquipStatusChangesService = equipStatusChangesService;
            PersonelService = personelService;
            Provider = provider;
            Logger = logger;

            var scope = provider.CreateAsyncScope();

           
            SheetsService = new SheetsService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = GoogleAuthentication.Login(
                        "1045168172166-8252afd2svev6d8h7gl8fsqvklb3eiia.apps.googleusercontent.com",
                        "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", new string[] { SheetsService.Scope.Spreadsheets }).Result
            });
            Logger = logger;
            shFactory = new SpreadsheetExportFactory(SheetsService);

        }

        public EquipmentUnitsService EquipmentUnitsService { get; }
        public AllEmployeesDBService AllEmployeesDBService { get; }
        public EquipStatusChangesService EquipStatusChangesService { get; }
        public PersonelService PersonelService { get; }
        public IServiceProvider Provider { get; }
        public GoogleSheetsExporter Exporter { get; private set; }
        public SheetsService SheetsService { get; }
        public ILogger<LoginsBlockedGoogleInvocable> Logger { get; }
        private SpreadsheetExportFactory shFactory;

        public async Task Invoke()
        {
            Exporter = new GoogleSheetsExporter(Provider, SheetsService, new List<GoogleSheetsExporter.SpreadsheetExport>()
            {
                 await shFactory.GetSpreadsheetExport("1peJmB7_u5srwycsF0WWwCdhRBcFDcLaIRBqA-Oiwj5o")
            });

         var loginsBlocked =  await PutLoginsBlocked();
        }

        private async Task<List<EquipmentLoginsBlocked>> PutLoginsBlocked()
        {
            var query = await EquipmentUnitsService.GetUnitsQueryAsync("Model.TypeNavigation", "ClientActivity.Client", "ClientActivity.Activity", "EquipStatusChanges.CurrentStatus", "EquipmentTransfers.ClientActivity.Client");
            query = query.TagWithCallSite();

            query = query.Include(c => c.Model.TypeNavigation);
            query = query.Include(c => c.ClientActivity.Client);
            query = query.Include(c => c.ClientActivity.Activity);
            query = query.Include(c => c.EquipStatusChanges).ThenInclude(c => c.CurrentStatus);
            query = query.Where(c => c.EquipStatusChanges.OrderBy(x => x.EquipStatusChangesID).LastOrDefault().CurrentStatusID == 1);
            query = query.Select(c => new EquipmentUnit()
            {
                EquipmentUnitsID = c.EquipmentUnitsID,
                SerialNumber = c.SerialNumber,
                ClientActivity = c.ClientActivity,
                Model = new EquipmentModel() { Model = c.Model.Model, ModelsID = c.Model.ModelsID, Type = c.Model.Type, TypeNavigation = c.Model.TypeNavigation },
                EquipStatusChanges = new List<EquipStatusChange>() { c.EquipStatusChanges.OrderBy(c => c.EquipStatusChangesID).LastOrDefault() },
                EquipmentTransfers = new List<EquipmentTransfer>() { c.EquipmentTransfers.OrderBy(x => x.EquipmentTransfersID).LastOrDefault() }
            });
            query = query.OrderBy(c => c.EquipmentUnitsID);
            try
            {
                var list = await query.ToListAsync();

                var tempQuery = query;
                var blockedEquip = list.Select(c => new
                {
                    Client = c.ClientActivity.Client.ClientName,
                    Model = c.Model.Model,
                    SerialNumber = c.SerialNumber,
                    EquipmentType = c.Model.TypeNavigation.Type,
                    TabelNum = c.EquipStatusChanges.FirstOrDefault()?.Login,
                    DateTimeTaken = c.EquipStatusChanges.LastOrDefault()?.DateTimeChanged ?? default,
                    CurrentClient = c.EquipStatusChanges.LastOrDefault()?.ClientActivity?.Client.ClientName

                }).ToList();

                var users = await AllEmployeesDBService.TryGetListEmployeesAsync(blockedEquip.Select(x => x.TabelNum).ToList());

                var loginBlockedList = blockedEquip.Join(users, c => c.TabelNum, x => x.PersonnelNumber, (x, c) => new EquipmentLoginsBlocked
                {
                    Client = x.Client,
                    Model = x.Model,
                    SerialNumber = x.SerialNumber,
                    EquipmentType = x.EquipmentType,
                    TabelNum = x.TabelNum,
                    FIO = c.FIO,
                    Company = c.Company,
                    DateTimeTaken = TimeZoneInfo.ConvertTimeFromUtc(x.DateTimeTaken, TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time")).ToString("dd.MM.yyyy HH:mm:ss"),
                    CurrentClient = x.CurrentClient
                }).OrderByDescending(c => c.DateTimeTaken).ToList();

                await Exporter.DeleteAll("Список сотрудников");
                await Exporter.Export("Список сотрудников", loginBlockedList);
                return loginBlockedList;
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); return null; }
        }
    }
}
