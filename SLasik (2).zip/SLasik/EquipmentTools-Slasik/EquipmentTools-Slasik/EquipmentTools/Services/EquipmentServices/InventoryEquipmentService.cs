﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;

namespace EquipmentTools.Services.EquipmentServices
{
    public class InventoryEquipmentService
    {
        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }
        public InventoryEquipmentService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }
        public async Task CreateInventoryUnitAsync(InventoryUnit inventoryEquipment)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.InventoryUnits.Add(inventoryEquipment);
            ctx.SaveChanges();
        }
    }
}
