﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;

namespace EquipmentTools.Services.EquipmentServices
{
    public class ServiceOrderShipmentServicee
    {
        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }

        public ServiceOrderShipmentServicee(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }

        // 1. Создание новой объединенной отгрузки из выбранных заявок
        public async Task<long> CreateShipmentFromOrdersAsync(List<long> orderIds, long initialStatusId)
        {
            await using var ctx = await DbContextFactory.CreateDbContextAsync();

            // Генерируем новый номер группы (максимальный текущий + 1)
            var maxGroupId = await ctx.ServiceOrderShipments
                .MaxAsync(s => (long?)s.ShipmentGroupId) ?? 0;
            long newGroupId = maxGroupId + 1;

            // Находим всё оборудование из выбранных заявок
            var unitIds = await ctx.ServiceOrderUnits
                .Where(u => u.ServiceOrdersID.HasValue && orderIds.Contains(u.ServiceOrdersID.Value))
                .Select(u => u.ServiceOrderUnitsID)
                .ToListAsync();

            // Создаем строки для каждой единицы оборудования с общим ShipmentGroupId
            var shipmentItems = unitIds.Select(unitId => new ServiceOrderShipment
            {
                ShipmentGroupId = newGroupId,
                ServiceOrderUnitsId = unitId,
                ServiceStatusesId = initialStatusId
            }).ToList();

            await ctx.ServiceOrderShipments.AddRangeAsync(shipmentItems);
            await ctx.SaveChangesAsync();

            return newGroupId;
        }

        // 2. Получение всей информации по конкретной отгрузке (статус + оборудование + заявки)
        public async Task<List<ServiceOrderShipment>> GetShipmentDetailsAsync(long shipmentGroupId)
        {
            await using var ctx = await DbContextFactory.CreateDbContextAsync();

            return await ctx.ServiceOrderShipments
                .Where(s => s.ShipmentGroupId == shipmentGroupId)
                .Include(s => s.ServiceStatuses)              // Подтягиваем статус
                .Include(s => s.ServiceOrderUnit)             // Подтягиваем позицию из заявки
                    .ThenInclude(u => u.Unit)                 // Подтягиваем само оборудование
                .Include(s => s.ServiceOrderUnit)
                    .ThenInclude(u => u.ServiceOrders)        // Подтягиваем данные самой заявки
                .ToListAsync();
        }

        // 3. Добавление еще одной заявки в уже существующую отгрузку
        public async Task AddOrderToShipmentAsync(long shipmentGroupId, long serviceOrderId)
        {
            await using var ctx = await DbContextFactory.CreateDbContextAsync();

            // Узнаем текущий статус этой отгрузки, чтобы новая заявка получила его же
            var currentStatusId = await ctx.ServiceOrderShipments
                .Where(s => s.ShipmentGroupId == shipmentGroupId)
                .Select(s => s.ServiceStatusesId)
                .FirstOrDefaultAsync();

            // Находим оборудование новой заявки (исключая то, что уже добавлено в эту отгрузку)
            var existingUnitIds = await ctx.ServiceOrderShipments
                .Where(s => s.ShipmentGroupId == shipmentGroupId)
                .Select(s => s.ServiceOrderUnitsId)
                .ToListAsync();

            var newUnitIds = await ctx.ServiceOrderUnits
                .Where(u => u.ServiceOrdersID == serviceOrderId && !existingUnitIds.Contains(u.ServiceOrderUnitsID))
                .Select(u => u.ServiceOrderUnitsID)
                .ToListAsync();

            var newItems = newUnitIds.Select(unitId => new ServiceOrderShipment
            {
                ShipmentGroupId = shipmentGroupId,
                ServiceOrderUnitsId = unitId,
                ServiceStatusesId = currentStatusId
            }).ToList();

            if (newItems.Any())
            {
                await ctx.ServiceOrderShipments.AddRangeAsync(newItems);
                await ctx.SaveChangesAsync();
            }
        }

        // 4. Удаление конкретной единицы оборудования из отгрузки
        public async Task RemoveUnitFromShipmentAsync(long shipmentGroupId, long serviceOrderUnitId)
        {
            await using var ctx = await DbContextFactory.CreateDbContextAsync();

            var item = await ctx.ServiceOrderShipments
                .FirstOrDefaultAsync(s => s.ShipmentGroupId == shipmentGroupId
                                       && s.ServiceOrderUnitsId == serviceOrderUnitId);

            if (item != null)
            {
                ctx.ServiceOrderShipments.Remove(item);
                await ctx.SaveChangesAsync();
            }
        }

        // 5. Удаление целой заявки из отгрузки
        public async Task RemoveOrderFromShipmentAsync(long shipmentGroupId, long serviceOrderId)
        {
            await using var ctx = await DbContextFactory.CreateDbContextAsync();

            var itemsToRemove = await ctx.ServiceOrderShipments
                .Where(s => s.ShipmentGroupId == shipmentGroupId
                         && s.ServiceOrderUnit.ServiceOrdersID == serviceOrderId)
                .ToListAsync();

            if (itemsToRemove.Any())
            {
                ctx.ServiceOrderShipments.RemoveRange(itemsToRemove);
                await ctx.SaveChangesAsync();
            }
        }

        // 6. Смена статуса у всей объединенной отгрузки
        public async Task UpdateShipmentStatusAsync(long shipmentGroupId, long newStatusId)
        {
            await using var ctx = await DbContextFactory.CreateDbContextAsync();

            var items = await ctx.ServiceOrderShipments
                .Where(s => s.ShipmentGroupId == shipmentGroupId)
                .ToListAsync();

            foreach (var item in items)
            {
                item.ServiceStatusesId = newStatusId;
            }

            await ctx.SaveChangesAsync();
        }
    }
}
