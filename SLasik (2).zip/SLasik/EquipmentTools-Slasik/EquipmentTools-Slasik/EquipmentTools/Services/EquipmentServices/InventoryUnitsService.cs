﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;

namespace EquipmentTools.Services.EquipmentServices
{
    public class InventoryUnitsService
    {
        public InventoryUnitsService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }

        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }

        public async Task<InventoryUnit> AddUnit(long memberId, long unitId, long clientActivityId)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            bool inventoryIsClosedOrContainsUnit = await ctx.InventoryUnits.Where(c => c.InventoryMemberID == memberId).AnyAsync(x => x.EquipmentUnitID == unitId || x.InventoryMember.Closed);

            if (inventoryIsClosedOrContainsUnit) return null;

            var entity = ctx.Add(new InventoryUnit { EquipmentUnitID = unitId, InventoryMemberID = memberId, ClientActivityID = clientActivityId });

            try
            {
                await ctx.SaveChangesAsync();
                return entity.Entity;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public async Task<List<InventoryUnit>> AddUnits(long memberId, List<long> unitIds, long clientActivityId)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            bool inventoryIsClosed = await ctx.InventoryUnits.Where(c => c.InventoryMemberID == memberId).AnyAsync(x => x.InventoryMember.Closed);

            if (inventoryIsClosed || !unitIds.Any()) return null;

            var duplicateUnits = await ctx.InventoryUnits.Where(c => c.InventoryMemberID == memberId && unitIds.Contains(c.EquipmentUnitID)).Select(c=>c.EquipmentUnitID).ToListAsync();
            var newUnits = unitIds.Except(duplicateUnits).Select(c => new InventoryUnit { EquipmentUnitID = c, InventoryMemberID = memberId, ClientActivityID = clientActivityId });
            ctx.InventoryUnits.AddRange(newUnits);

            try
            {
                await ctx.SaveChangesAsync();
                return newUnits.ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
