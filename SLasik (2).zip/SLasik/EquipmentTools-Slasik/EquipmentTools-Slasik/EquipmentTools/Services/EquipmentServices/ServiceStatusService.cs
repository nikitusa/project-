﻿using EquipmentTools.Models.EquipmentContext;
using EquipmentTools.Services.EquipmentSerices;
using Microsoft.EntityFrameworkCore;

namespace EquipmentTools.Services.EquipmentServices
{
    public class ServiceStatusService
    {
        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }
        public ServiceStatusService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }

        public async Task<List<ServiceStatus>> getAllStatusesAsync()
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            var list = ctx.ServiceStatuses.ToList();
            return list;
        }
    }
}
