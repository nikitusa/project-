﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace EquipmentTools.Services.EquipmentSerices
{
    public class ClientService
    {
        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }
        public ClientService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }

        public async Task<string> GetClientAsync(int actID)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            var activity = await ctx.ClientActivities.Where(c => c.ClientActivityID == actID).FirstOrDefaultAsync();

            if (activity == null)
            {
                return null;
            }

            var client = await ctx.Clients
                .Where(c => c.ClientsID == activity.ClientID)
                .FirstOrDefaultAsync();

            if (client == null)
            {
                return null;
            }

            return client.ClientName;
        }
        public async Task<string> GetActivityName(int actID)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            var activity = await ctx.ClientActivities.Where(c => c.ClientActivityID == actID).FirstOrDefaultAsync();
            var activityName = await ctx.Activities.Where(c=>c.ActivityID==activity.ActivityID).FirstOrDefaultAsync();
            return activityName.ActivityName;

       


        }

        public async Task<List<Client>> GetClientsAsync(params string[] includes)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            var query = ctx.Clients.AsQueryable();

            query = includes.Aggregate(query, (current, includePropery) => current.Include(includePropery));

            var client = await query.Include(c=>c.Platform).ToListAsync();
            return client;
        }
        public async Task AddClientAsync(Client client)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.Clients.Add(client);
            ctx.SaveChanges();
        }
    }
}
