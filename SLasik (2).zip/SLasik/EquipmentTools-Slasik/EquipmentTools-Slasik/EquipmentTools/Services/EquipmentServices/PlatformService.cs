﻿using EquipmentTools.Models.EquipmentContext;
using EquipmentTools.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace EquipmentTools.Services.EquipmentSerices
{
    public class PlatformService
    {
        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }
        public PlatformService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }
        public async Task<List<Platform>> GetPlatformsAsync()
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            var platforms = await ctx.Platforms.ToListAsync();
            return platforms;


        }
 
        public async Task<IQueryable<Platform>> GetPlatformsFilteredAsync(Expression<Func<Platform, bool>> predicate, params string[] includes)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            var query = ctx.Platforms.AsQueryable();

            query = includes.Aggregate(query, (current, includePropery) => current.Include(includePropery));
            if (predicate != null)
            {
                query = query.Where(predicate);
            }


            return query;
        }
        public async Task AddPlatformAsync(Platform platform)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.Platforms.Add(platform);
            ctx.SaveChanges();
        }
    }
}

