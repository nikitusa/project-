﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;
using MudBlazor;
using System.Linq.Expressions;


namespace EquipmentTools.Services.EquipmentSerices
{
    public class ServiceOrderService
    {
        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }
        public ServiceOrderService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }
        public async Task<ServiceOrder> AddServiceOrderAsync(ServiceOrder value)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.ServiceOrders.Add(value);
            await ctx.SaveChangesAsync();
            return value;
        }

        public async Task<IQueryable<ServiceOrder>> GetServiceOrdersQueryAsync(Expression<Func<ServiceOrder, bool>> filter, params string[] includes)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            var query = ctx.ServiceOrders.AsQueryable();

            if(filter != null)
            {
                query = query.Where(filter);
            }

            query = includes.Aggregate(query, (current, includePropery) => current.Include(includePropery));

            return query;
        }

        
        public async Task<bool> TryCloseITServiceOrder(ServiceOrderUnit orderUnit)
        {
            EquipmentContext ctx;
            if (orderUnit == null)
            {
                return false;
            }
            ctx = await DbContextFactory.CreateDbContextAsync();

            var order = await ctx.ServiceOrders
                .Include(c=>c.ServiceOrderStatuses)
                .Include(c=>c.ServiceOrderUnits)
                .ThenInclude(c=>c.Unit)
                .ThenInclude(c=>c.EquipStatusChanges)
                .ThenInclude(c=>c.CurrentStatus)
                .FirstOrDefaultAsync(c=>c.ServiceOrderUnits.Any(x=>x.ServiceOrderUnitsID == orderUnit.ServiceOrderUnitsID));

            if(order == null)
            {
                throw new ArgumentException("Заявка на сервис не найдена");
            }

            if(order.ServiceOrderStatuses.OrderBy(c=>c.ServiceOrderStatusesID).LastOrDefault()?.StatusID == 5)
            {
                var equipmentInServiceCount = order.ServiceOrderUnits.Count(c => c.Unit.EquipStatusChanges.OrderBy(x => x.EquipStatusChangesID).LastOrDefault().CurrentStatusID == 5);

                if(equipmentInServiceCount == 1) 
                { 
                    order.ServiceOrderStatuses.Add(new ServiceOrderStatus() { StatusID = 6 });
                    await ctx.SaveChangesAsync();
                    return true;
                }
            }

            return false;
        }
    }
}
