﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace EquipmentTools.Services.EquipmentServices
{
    public class InventoryMembersService
    {
        public InventoryMembersService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }

        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }

        public async Task<IQueryable<InventoryMember>> GetInventoriesQuery(Expression<Func<InventoryMember, bool>> filter)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            var query = ctx.InventoryMembers.AsQueryable();

            if (filter != null)
            {
                query = query.Where(filter);
            }

            return query;
        }

        public async Task UpdateMembers(IEnumerable<InventoryMember> members)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            ctx.InventoryMembers.UpdateRange(members);

            await ctx.SaveChangesAsync();
        }
    }
}
