﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;

namespace EquipmentTools.Services.EquipmentServices
{
    public class ServiceOrdersStatusesService
    {
        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }

        public ServiceOrdersStatusesService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }
        public async Task SetServiceOrdersStatusAsync(ServiceOrderStatus serviceOrderStatus) 
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.Add(serviceOrderStatus);
           await ctx.SaveChangesAsync();
        }
    }
}
