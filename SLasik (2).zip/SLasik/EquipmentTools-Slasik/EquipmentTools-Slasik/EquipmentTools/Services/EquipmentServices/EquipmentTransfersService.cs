﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;

namespace EquipmentTools.Services.EquipmentSerices
{
    public class EquipmentTransfersService
    {
        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }
        public EquipmentTransfersService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }
        public async Task<EquipmentTransfer> SetTransferEquipment(EquipmentTransfer value)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.Add(value);
            await ctx.SaveChangesAsync();
            return value;
        }
        public async Task<List<EquipmentTransfer>> AddEquipmentTransfers(List<EquipmentTransfer> values)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.AddRange(values);
            await ctx.SaveChangesAsync();
            return values;
        }

        public async Task<EquipmentTransfer?> GetCurrentTransfer(long equipmentId, params string[] includes)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            var query = ctx.EquipmentTransfers.AsQueryable();

            query = includes.Aggregate(query, (current, includePropery) => current.Include(includePropery));

            var transfer = await query
                .OrderBy(c => c.EquipmentTransfersID).TagWith("EquipmentTransfersService:GetCurrentTransfer").LastOrDefaultAsync(c => c.UnitID == equipmentId);

            return transfer;
        }
    }
}
