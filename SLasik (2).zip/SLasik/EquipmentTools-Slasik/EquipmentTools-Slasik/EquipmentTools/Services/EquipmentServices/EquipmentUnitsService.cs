﻿
using EquipmentTools.Models.EquipmentContext;
using EquipmentTools.Data;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace EquipmentTools.Services.EquipmentSerices
{
    public class EquipmentUnitsService
    {
        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }
        public EquipmentUnitsService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }
        public async Task<IQueryable<EquipmentUnit>> GetUnitsFilteredAsync(Expression<Func<EquipmentUnit, bool>> predicate, params string[] includes)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            var query = ctx.EquipmentUnits.AsQueryable();

            query = includes.Aggregate(query, (current, includePropery) => current.Include(includePropery));
            if (predicate != null)
            {
                query = query.Where(predicate);
            }


            return query;
        }
        public async Task<IQueryable<EquipmentUnit>> GetUnitsQueryAsync(params string[] includes)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            //var a = await ctx.Database.SqlQuery<string>($"show work_mem").ToListAsync();

            var query = ctx.EquipmentUnits.AsQueryable();

            query = query.TagWith("EquipmentUnitsService:GetUnitsQueryAsync");

            query = includes.Aggregate(query, (current, includePropery) => current.Include(includePropery));

            return query;
        }
        public async Task<EquipmentUnit> GetUnitAsync(string value)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            var result = await ctx.EquipmentUnits.AsQueryable().TagWith("EquipmentUnitsService:GetUnitAsync")
            .Where(c => c.SerialNumber == value)
            .Include(c => c.ServiceOrderUnits)
                .ThenInclude(c => c.ServiceOrders)
                .ThenInclude(c => c.ServiceOrderStatuses)
            .Include(c => c.EquipmentTransfers)
                .ThenInclude(c => c.ClientActivity)
                    .ThenInclude(c => c.Client)
            .Include(c => c.EquipmentTransfers)
                .ThenInclude(c => c.ClientActivity)
                    .ThenInclude(c => c.Activity)
            .Include(c => c.EquipStatusChanges)
                .ThenInclude(c => c.CurrentStatus)
            .Select(c => new EquipmentUnit()
            {
                EquipmentUnitsID = c.EquipmentUnitsID,
                Client = c.Client,
                ClientID = c.ClientID,
                ClientActivity = c.ClientActivity != null
                    ? new ClientActivity()
                    {
                        ClientActivityID = c.ClientActivity.ClientActivityID,
                        Activity = c.ClientActivity.Activity,
                        ActivityID = c.ClientActivity.ActivityID,
                        ClientID = c.ClientActivity.ClientID,
                        Client = c.ClientActivity.Client
                    }
                    : null,
                ClientActivityID = c.ClientActivityID,
                Model = new EquipmentModel()
                {
                    ModelsID = c.Model.ModelsID,
                    Model = c.Model.Model,
                    Type = c.Model.Type,
                    TypeNavigation = c.Model.TypeNavigation
                },
                ModelID = c.ModelID,
                CreatedDate = c.CreatedDate,
                SerialNumber = c.SerialNumber,
                // Вместо использования LastOrDefault() с OrderBy, можно использовать Max или просто взять последний элемент,
                // если элементы отсортированы в нужном порядке (если поддерживается).
                EquipmentTransfers = c.EquipmentTransfers
                    .OrderByDescending(x => x.EquipmentTransfersID)
                    .Take(1)
                    .ToList(),
                EquipStatusChanges = c.EquipStatusChanges
                    .OrderByDescending(x => x.EquipStatusChangesID)
                    .Take(1)
                    .ToList(),
                ServiceOrderUnits = c.ServiceOrderUnits
                    .OrderByDescending(x => x.ServiceOrdersID)
                    .Take(1)
                    .ToList(),
            })
            .ToListAsync();

            //.FirstOrDefaultAsync(c=>c.SerialNumber == value);
            return result.FirstOrDefault();
        }

        public async Task<List<EquipmentUnit>> GetLoginEquipmentInUse(string login, params string[] includes)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            var query = ctx.EquipmentUnits.AsQueryable();

            query = query.TagWith("EquipmentUnitsService:GetLoginEquipmentInUse");

            var statusQuery = ctx.EquipStatusChanges.AsQueryable();

            query = includes.Aggregate(query, (current, includePropery) => current.Include(includePropery));
            statusQuery = includes.Aggregate(statusQuery, (current, includePropery) => current.Include(includePropery));

            statusQuery = statusQuery.TagWith("EquipmentUnitsService:GetLoginEquipmentInUse");

            var equipmentInUse = await statusQuery.GroupBy(c => new { c.EquipID }).Select(c => new { EquipStatusChangesID = c.Max(x => x.EquipStatusChangesID) })
                .Join(statusQuery.Where(c => c.Login == login && c.CurrentStatusID == 1), c => c.EquipStatusChangesID, x => x.EquipStatusChangesID, (c, x) => x.Equip)
                .ToListAsync();

            //var loginEquipment = await query.Where(c=>c.EquipStatusChanges.OrderBy(x=>x.EquipStatusChangesID).Last().Login == login && c.EquipStatusChanges.OrderBy(x => x.EquipStatusChangesID).Last().CurrentStatusID == 1)
            //    .WithLastChanges()
            //    .ToListAsync();

            return equipmentInUse;
        }

        public async Task GetUnitsPresentOnActivity(int clientActivityID)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            var clientActivityUnitsQuery = ctx.ClientActivities.Include(c => c.EquipmentUnits)
                .Where(c => c.ClientActivityID == clientActivityID)
                .SelectMany(c => c.EquipmentUnits.Where(c => c.EquipmentTransfers.OrderBy(x => x.EquipmentTransfersID).LastOrDefault() == null || c.EquipmentTransfers.OrderBy(x => x.EquipmentTransfersID).LastOrDefault().Return == true));

            var units = await clientActivityUnitsQuery.ToListAsync();
        }
        public async Task<IQueryable<EquipmentUnit>> GetUnitsPresentOnActivityQueryAsync(int clientActivityID, params string[] includes)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            var query = ctx.ClientActivities.AsQueryable();
            var unitsQuery = ctx.EquipmentUnits.AsQueryable();

            //query = includes.Aggregate(query, (current, includePropery) => current.Include(includePropery));
            unitsQuery = includes.Aggregate(unitsQuery, (current, includePropery) => current.Include(includePropery));

            unitsQuery = unitsQuery.TagWith("EquipmentUnitsService:GetUnitsPresentOnActivityQueryAsync");

            var clientActivityUnitsQuery = query.Include(c => c.EquipmentUnits)
                .SelectMany(c => c.EquipmentUnits.Where(c => (c.EquipmentTransfers.OrderBy(x => x.EquipmentTransfersID).LastOrDefault() == null && c.ClientActivity.ClientActivityID == clientActivityID) || c.EquipmentTransfers.OrderBy(x => x.EquipmentTransfersID).LastOrDefault().ClientActivityID == clientActivityID));

            var clientActivityUnitsQuery1 = unitsQuery.Where(c => c.EquipmentTransfers.Any() && c.EquipmentTransfers.OrderBy(x => x.EquipmentTransfersID).Last().ClientActivityID == clientActivityID || !c.EquipmentTransfers.Any() && c.ClientActivityID == clientActivityID);

            //var b = await clientActivityUnitsQuery1.ToListAsync();

            //var res = await clientActivityUnitsQuery.FirstOrDefaultAsync(c => c.SerialNumber == "2219010276");

            return clientActivityUnitsQuery1;
        }

        public async Task<IQueryable<EquipmentUnit>> GetUnitsTransferredToActivity(int clientActivityID, params string[] includes)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            var query = ctx.EquipmentUnits.AsQueryable();

            query = includes.Aggregate(query, (current, includePropery) => current.Include(includePropery));

            query = query.TagWith("EquipmentUnitsService:GetUnitsTransferredToActivity");

            var transferredEquipment = query.Where(c => c.ClientActivityID != clientActivityID && c.EquipmentTransfers.OrderBy(x => x.EquipmentTransfersID).LastOrDefault().ClientActivityID == clientActivityID);

            return transferredEquipment;
        }

        public async Task<IQueryable<EquipmentUnit>> GetUnitsTransferedFromActivityQueryAsync(int clientActivityID, params string[] includes)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            var query = ctx.ClientActivities.AsQueryable();

            query = query.TagWith("EquipmentUnitsService:GetUnitsTransferedFromActivityQueryAsync");

            query = includes.Aggregate(query, (current, includePropery) => current.Include(includePropery));

            //var clientActivityUnitsQuery = query.Include(c => c.EquipmentUnits)
            //    .Where(c => c.ClientActivityID == clientActivityID)
            //    .SelectMany(c => c.EquipmentUnits.Where(c => c.EquipmentTransfers.OrderBy(x => x.EquipmentTransfersID).LastOrDefault() != null && c.EquipmentTransfers.OrderBy(x => x.EquipmentTransfersID).LastOrDefault().ClientActivityID != clientActivityID));

            var clientActivityUnitsQuery = query.Include(c => c.EquipmentUnits)
                .Where(c => c.ClientActivityID == clientActivityID)
                .SelectMany(c => c.EquipmentUnits.Where(c => c.EquipmentTransfers.OrderBy(x => x.EquipmentTransfersID).LastOrDefault() != null && !c.EquipmentTransfers.OrderBy(x => x.EquipmentTransfersID).LastOrDefault().ClientActivity.Client.ClientActivities.Any(x=>x.ClientActivityID == clientActivityID)));


            //var a = await clientActivityUnitsQuery.ToListAsync();

            return clientActivityUnitsQuery;
        }

        public async Task<List<EquipmentUnit>> AddNewEquipmentListAsync(List<EquipmentUnit> units)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.EquipmentUnits.AddRange(units);
            await ctx.SaveChangesAsync();
            return units;
        }

        public async Task<List<EquipmentUnit>> UpdateEquipment(List<EquipmentUnit> equipmentUnit)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.EquipmentUnits.UpdateRange(equipmentUnit);
            await ctx.SaveChangesAsync();



            return equipmentUnit;
        }





        //public async Task<EquipmentUnit> CountWorkUnitsAsync()
        //{
        //    var ctx = await DbContextFactory.CreateDbContextAsync();
        //    //var result = await ctx.EquipmentUnits.Include(c => c.EquipStatusChanges).ThenInclude(x => x.CurrentStatus);
        //}
    }
}
