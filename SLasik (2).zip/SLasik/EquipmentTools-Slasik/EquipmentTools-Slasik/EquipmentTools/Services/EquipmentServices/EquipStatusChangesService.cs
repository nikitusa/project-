﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics.Metrics;
using System.Linq.Expressions;

namespace EquipmentTools.Services.EquipmentSerices
{
    public class EquipStatusChangesService
    {
        private IDbContextFactory<EquipmentContext> DbContextFactory { get; }

        private static readonly Meter MeterInstance = new Meter("EquipStatusChangesService");

        private static readonly Dictionary<string, Histogram<double>> Histogram = new Dictionary<string, Histogram<double>>();

        private IEnumerable<string> histogramNames = new string[] { "GetEquipStatusChangesQueryAsync" };

        public EquipStatusChangesService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;

            //foreach (var methodName in histogramNames)
            //{
            //    Histogram[methodName] = MeterInstance.CreateHistogram<double>(methodName, "ms");
            //}
        }

        public async Task<IQueryable<EquipStatusChange>> GetEquipStatusChangesQueryAsync(Expression<Func<EquipStatusChange, bool>> predicate, params string[] includes)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            var query = ctx.EquipStatusChanges.AsQueryable();

            query = includes.Aggregate(query, (current, includePropery) => current.Include(includePropery));

            query = query.TagWith("EquipStatusChangesService:GetEquipStatusChangesQueryAsync");

            if (predicate != null)
            {
                query = query.Where(predicate);
            }


            return query;
        }

        public async Task<IEnumerable<T>> ExecuteQuery<T>(IQueryable<T> query)
        {
            var a  = await query.ToListAsync();

            return a;
        }

        public async Task<List<EquipStatusChange>> SetEquipStasusListAsync(List<EquipStatusChange> equips)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.AddRange(equips);
            await ctx.SaveChangesAsync();
            return equips;
        }
        public async Task<EquipStatusChange> SetEquipStatusAsync(EquipStatusChange value)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.Add(value);
            await ctx.SaveChangesAsync();
            return value;
        }
  
    }
}
