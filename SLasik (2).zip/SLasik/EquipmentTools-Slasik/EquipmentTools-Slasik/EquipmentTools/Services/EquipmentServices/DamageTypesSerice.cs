﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;

namespace EquipmentTools.Services.EquipmentSerices
{
    public class DamageTypesSerice
    {
        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }
        public DamageTypesSerice(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }

        public async Task<List<DamageType>> GetDamageTypesAsync()
        {
            var ctx = DbContextFactory.CreateDbContext();
            var damageTypes = await ctx.DamageTypes.ToListAsync();
            return damageTypes;
        }
        public async Task AddDamageTypeAsync(DamageType damageType)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.DamageTypes.Add(damageType);
            ctx.SaveChanges();
        }
    }
}
