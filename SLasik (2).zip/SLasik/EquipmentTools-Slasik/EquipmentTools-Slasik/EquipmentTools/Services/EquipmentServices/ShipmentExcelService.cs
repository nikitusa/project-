﻿
using ClosedXML.Excel;
using EquipmentTools.Data;
using EquipmentTools.Models.EquipmentContext;

namespace EquipmentTools.Services.EquipmentServices
{
    public enum ShipmentExcelType
    {
        SmartService,
        ServiceTelecom
    }

    public class ShipmentExcelService
    {
        public byte[] GenerateExcel(
            ServiceOrderShipmentGroup shipmentGroup,
            IEnumerable<long> selectedEquipmentIds,
            ShipmentExcelType serviceType)
        {
            var selectedIds = selectedEquipmentIds.Distinct().ToHashSet();

            var equipment = shipmentGroup.ServiceOrderUnits
                .Where(unit => selectedIds.Contains(unit.ServiceOrderUnitsID))
                .ToList();

            if (equipment.Count == 0)
            {
                throw new InvalidOperationException(
                    "Сначала выберите оборудование для Excel-файла.");
            }

            using var workbook = new XLWorkbook();

            var worksheet = workbook.Worksheets.Add("Объединённая заявка");

            switch (serviceType)
            {
                case ShipmentExcelType.SmartService:
                    CreateSmartServiceExcel(worksheet, equipment);
                    break;

                case ShipmentExcelType.ServiceTelecom:
                    CreateServiceTelecomExcel(worksheet, equipment);
                    break;

                default:
                    throw new ArgumentOutOfRangeException(nameof(serviceType));
            }

            using var stream = new MemoryStream();

            workbook.SaveAs(stream);

            return stream.ToArray();
        }

        private void CreateSmartServiceExcel(
            IXLWorksheet worksheet,
            List<ServiceOrderUnit> equipment)
        {
            worksheet.Cell(1, 1).Value = "№";
            worksheet.Cell(1, 2).Value = "Модель";
            worksheet.Cell(1, 3).Value = "Серийный номер";
            worksheet.Cell(1, 4).Value = "Описание неисправности";

            for (int i = 0; i < equipment.Count; i++)
            {
                var unit = equipment[i];
                int row = i + 2;

                worksheet.Cell(row, 1).Value = i + 1;
                worksheet.Cell(row, 2).Value =
                    unit.Unit?.Model?.Model ?? "";

                worksheet.Cell(row, 3).Value =
                    unit.Unit?.SerialNumber ?? "";

                worksheet.Cell(row, 4).Value = "";
            }

            FormatWorksheet(worksheet, 4);
        }

        private void CreateServiceTelecomExcel(
            IXLWorksheet worksheet,
            List<ServiceOrderUnit> equipment)
        {
            worksheet.Cell(1, 1).Value = "№";
            worksheet.Cell(1, 2).Value = "Наименование";
            worksheet.Cell(1, 3).Value = "Серийный номер";
            worksheet.Cell(1, 4).Value = "IT номер";
            worksheet.Cell(1, 5).Value = "Клиент";
            worksheet.Cell(1, 6).Value = "Комплектность";
            worksheet.Cell(1, 7).Value = "Описание неисправности";

            for (int i = 0; i < equipment.Count; i++)
            {
                var unit = equipment[i];
                int row = i + 2;

                worksheet.Cell(row, 1).Value = i + 1;
                worksheet.Cell(row, 2).Value =
                    unit.Unit?.Model?.Model ?? "";

                worksheet.Cell(row, 3).Value =
                    unit.Unit?.SerialNumber ?? "";

                // Эти поля пока заполняются вручную.
                worksheet.Cell(row, 4).Value = "";
                worksheet.Cell(row, 5).Value = "";
                worksheet.Cell(row, 6).Value = "";
                worksheet.Cell(row, 7).Value = "";
            }

            FormatWorksheet(worksheet, 7);
        }

        private void FormatWorksheet(IXLWorksheet worksheet, int columnCount)
        {
            var header = worksheet.Range(1, 1, 1, columnCount);

            header.Style.Font.Bold = true;
            header.Style.Alignment.Horizontal =
                XLAlignmentHorizontalValues.Center;

            header.Style.Alignment.Vertical =
                XLAlignmentVerticalValues.Center;

            header.Style.Fill.BackgroundColor = XLColor.LightGray;

            header.Style.Border.OutsideBorder =
                XLBorderStyleValues.Thin;

            header.Style.Border.InsideBorder =
                XLBorderStyleValues.Thin;

            var lastRow = worksheet.LastRowUsed()?.RowNumber() ?? 1;

            var table = worksheet.Range(1, 1, lastRow, columnCount);

            table.Style.Border.OutsideBorder =
                XLBorderStyleValues.Thin;

            table.Style.Border.InsideBorder =
                XLBorderStyleValues.Thin;

            table.Style.Alignment.Vertical =
                XLAlignmentVerticalValues.Center;

            worksheet.Columns(1, columnCount).AdjustToContents();
        }
    }
}
