﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace EquipmentTools.Services.EquipmentServices
{
    public class EmployeeBadgesService
    {
        private IDbContextFactory<EquipmentContext> DbContextFactory { get; }
        public EmployeeBadgesService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }

        public async Task<List<Employee>> GetEmployeeBadgesAsync(Expression<Func<Employee, bool>> filter)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            var query = ctx.Employees.AsQueryable();

            if(filter != null)
            {
                query = query.Where(filter);
            }

            return await query.ToListAsync();
        }
        public async Task<IQueryable<Employee>> GetEmployeeBadgesQueryAsync(Expression<Func<Employee, bool>> filter)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            var query = ctx.Employees.AsQueryable();

            if(filter != null)
            {
                query = query.Where(filter);
            }

            return query;
        }
    }
}
