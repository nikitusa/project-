﻿
using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;


namespace EquipmentTools.Services.EquipmentSerices
{
    public class EquipStatusService
    {
        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }
        public EquipStatusService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }

        public async Task<IQueryable<EquipStatus>> GetEquipStatusesQueryAsync(Expression<Func<EquipStatus, bool>> predicate, params string[] includes)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            var query = ctx.EquipStatuses.AsQueryable();

            query = includes.Aggregate(query, (current, includePropery) => current.Include(includePropery));
            if (predicate != null)
            {
                query = query.Where(predicate);
            }


            return query;
        }
        public async Task<List<EquipStatus>> GetAllStatusAsync()
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            var result = await ctx.EquipStatuses.ToListAsync();
            return result;
        }

        public async Task AddStatusAsync(EquipStatus status)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.EquipStatuses.Add(status);
            ctx.SaveChanges();
        }
    }
}
