﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace EquipmentTools.Services.EquipmentServices
{
    public class InventoriesService
    {
        public InventoriesService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }

        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }

        public async Task<Inventory> AddNewInventory(Inventory inventory)
        {
            if (inventory == null) throw new ArgumentNullException("Не передана запись инвентаризации");

            var ctx = await DbContextFactory.CreateDbContextAsync();

            ctx.Inventories.Add(inventory);
            await ctx.SaveChangesAsync();
            return inventory;
        }

        public async Task<IQueryable<Inventory>> GetInventoriesQuery(Expression<Func<Inventory, bool>> filter, params string[] includes)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            var query = ctx.Inventories.AsQueryable();

            query = includes.Aggregate(query, (current, includePropery) => current.Include(includePropery));

            if (filter != null)
            {
                query = query.Where(filter);
            }

            return query;
        }
    }
}
