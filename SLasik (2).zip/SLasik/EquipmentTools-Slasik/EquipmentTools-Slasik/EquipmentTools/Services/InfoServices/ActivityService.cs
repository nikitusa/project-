﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;

namespace EquipmentTools.Services.InfoServices
{
    public class ActivityService
    {
        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }
        public ActivityService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }
        public async Task AddActivityAsync(Activity act)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.Activities.Add(act);
            ctx.SaveChanges();
        }
    }
}
