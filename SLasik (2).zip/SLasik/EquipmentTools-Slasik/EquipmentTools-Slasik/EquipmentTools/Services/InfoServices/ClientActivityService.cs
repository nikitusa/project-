﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace EquipmentTools.Services.InfoServices
{
    public class ClientActivityService
    {
        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }
        public ClientActivityService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }
        public async Task AddClientActivityAsync(ClientActivity clientActivity)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.ClientActivities.Add(clientActivity);
            ctx.SaveChanges();
        }

        public async Task<List<ClientActivity>> GetClientActivities(Expression<Func<ClientActivity, bool>> predicate)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            var query = ctx.ClientActivities.AsQueryable();

            if (predicate != null)
            {
                query = query.Where(predicate);
            }

            return await query.ToListAsync();
        }

        public async Task<ClientActivity> GetClientActivity(Expression<Func<ClientActivity, bool>> predicate)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            var query = ctx.ClientActivities.AsQueryable();

            if (predicate != null)
            {
                return await query.FirstOrDefaultAsync(predicate);
            }

            else return null;
        }
    }
}
