﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;
using System.Drawing;

namespace EquipmentTools.Services.InfoServices
{
    public class EquipmentModelService
    {
        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }
        public EquipmentModelService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }
        public async Task AddEquipmentModelAsync(EquipmentModel model)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.EquipmentModels.Add(model);
            ctx.SaveChanges();
        }

        public async Task<List<EquipmentModel>> GetAllModelAsync()
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
           var value = await ctx.EquipmentModels.Include(c=>c.TypeNavigation).ToListAsync();
            return value;
        }
        public async Task<byte[]> GetImageAsync()
        {
            var client = new HttpClient();
            var responce = await client.GetAsync("http://qrcoder.ru/code/?XXQVJ152200098&4&");
            var bytes = await responce.Content.ReadAsByteArrayAsync();
            //using(Image image = Image.FromStream(ms))
            return bytes;



        }
    
    }
}
