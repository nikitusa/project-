﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;

namespace EquipmentTools.Services.InfoServices
{
    public class EquipmentTypesService
    {
        public IDbContextFactory<EquipmentContext> DbContextFactory { get; }
        public EquipmentTypesService(IDbContextFactory<EquipmentContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }
        public async Task AddEquipmentTypeAsync(EquipmentType type)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            ctx.EquipmentTypes.Add(type);
            ctx.SaveChanges();
        }
    }

}
