﻿using System.Net.Http.Headers;

namespace EquipmentTools.Services
{
    public class TokenDelegatingHandler : DelegatingHandler
    {
        private UserService _userService;

        private string _token;

        public TokenDelegatingHandler(IServiceProvider provider)
        {
            using (var scope = provider.CreateAsyncScope())
            {
                _userService = scope.ServiceProvider.GetRequiredService<UserService>();
            }
        }
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            string token = _userService.GetUserToken();

            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

            return await base.SendAsync(request, cancellationToken);
        }
    }
}
