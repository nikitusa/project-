﻿namespace HR_Transfers_WebAPI.Services
{
    public class TimeSlotAction<T>
    {
        public TimeSpan TargetTime { get; private set; }
        public Task TimedAction { get; private set; }

        private CancellationToken _token;

        private PeriodicTimer _timer;

        private Task _action;

        //public async Task<T> Execute() {
        //    if (DateTime.Now.TimeOfDay >= From && DateTime.Now.TimeOfDay <= To)
        //        return await TimedAction;

        //    return default(T);
        //}

        public Task GetTask() => _action;

        private TimeSpan GetTargetTime()
        {
            var target = (DateTime.Now.TimeOfDay > TargetTime ? DateTime.Now.Date.AddDays(1).Add(TargetTime) : DateTime.Now.Date.Add(TargetTime)) - DateTime.Now;
            return target;
        }

        private async Task<TimeSlotAction<T>> Execute()
        {
            var timer = new PeriodicTimer(GetTargetTime());

            while(timer != null && await timer.WaitForNextTickAsync(_token))
            {
                _action.Start();
                await _action.WaitAsync(_token);

                timer = new PeriodicTimer(GetTargetTime());              
            }

            return this;
        }
    

        public TimeSlotAction(TimeSpan targetTime, Action action, CancellationToken token)
        {
            TargetTime = targetTime;
            TimedAction = new Task(action);
            _token = token;
            _action = TimedAction;

            Execute();
        }
    }
}
