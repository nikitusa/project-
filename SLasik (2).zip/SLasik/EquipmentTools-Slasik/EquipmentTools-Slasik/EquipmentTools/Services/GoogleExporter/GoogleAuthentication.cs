﻿using Google.Apis.Auth.OAuth2;

namespace HR_Transfers_WebAPI.Google
{
    public static class GoogleAuthentication
    {
        public static async Task<UserCredential> Login(string clientId, string clientSecret, string[] scopes)
        {
            ClientSecrets secrets = new ClientSecrets()
            {
                ClientId = clientId,
                ClientSecret = clientSecret
            };
            return await GoogleWebAuthorizationBroker.AuthorizeAsync(secrets, scopes, "user", CancellationToken.None);
        }
    }
}
