﻿using Google.Apis.Services;
using Google.Apis.Sheets.v4.Data;
using Google.Apis.Sheets.v4;
using HR_Transfers_WebAPI.Google;
using static Google.Apis.Sheets.v4.SpreadsheetsResource.ValuesResource;
using System.Collections;
using static System.Runtime.InteropServices.JavaScript.JSType;
using Google.Apis.Requests;

namespace HR_Transfers_WebAPI.Services.GoogleSheets
{
    public class GoogleSheetsExporter
    {
        public class SpreadsheetExport
        {
            public string SpreadsheetID { get; private set; }
            public string SpreadsheetName { get; private set; }
            public List<string> SheetNames { get; private set; }

            public Spreadsheet Spreadsheet { get; private set; }

            public SpreadsheetExport(string spreadsheetID)
            {
                SpreadsheetID = spreadsheetID;
                SheetNames = new List<string>();
            }

            public async Task<SpreadsheetExport> Initialize(SheetsService sheetsService)
            {
                try
                {
                    Spreadsheet = await sheetsService.Spreadsheets.Get(SpreadsheetID).ExecuteAsync();
                    SpreadsheetName = Spreadsheet.Properties.Title;
                    if (Spreadsheet == null)
                    {
                        Console.WriteLine("Ошибка Google Sheets: не удалось найти указанный документ");
                        return null;
                    }

                    foreach (Sheet sheet in Spreadsheet.Sheets)
                    {
                        SheetNames.Add(sheet.Properties.Title);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{ex.Message}\n{ex.StackTrace}");
                }
                finally
                {
                    if (SheetNames.Count <= 0)
                    {
                        Console.WriteLine($"Не удалось загрузить указанный документ Google Sheets: " + SpreadsheetID);
                    }
                }
                return this;
            }
        }

        private IServiceProvider Provider { get; set; }

        private static SheetsService _sheetsService;

        SpreadsheetsResource.ValuesResource googleSheetValues { get; set; }

        private static SheetsService SheetsService { get; set; }

        private readonly List<SpreadsheetExport> _sheets;

        private List<Task> initializingSpreadsheets = new List<Task>();

        public GoogleSheetsExporter(IServiceProvider provider, SheetsService sheetsService, List<SpreadsheetExport> sheets)
        {
            SheetsService = sheetsService;
            _sheets = sheets;

            if (sheets.Count < 0) return;

            Provider = provider;
            try
            {
                googleSheetValues = SheetsService.Spreadsheets.Values;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

        }

        public async Task<IList<IList<object>>> GetSheetValues(string sheetName, string range = null)
        {
            try
            {
                var exportItem = _sheets.FirstOrDefault(c => c.SheetNames.FirstOrDefault(c => c.ToLower().Contains(sheetName.ToLower())) != null);
                if(exportItem == null)
                {
                    Console.WriteLine($"Не удалось найти лист {sheetName}");
                    return null;
                }
                var sheetRange = $"{sheetName}{(range != null ? $"!{range}" : string.Empty)}";
                var sheetsInfo = await SheetsService.Spreadsheets.Values.Get(exportItem.SpreadsheetID, sheetRange).ExecuteAsync();
                var data = sheetsInfo.Values;
                return data;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            return null;
        }

        private List<IList<object>> GetObjectList(IList values)
        {
            List<IList<object>> data = new List<IList<object>>();

            IList<object> row = new List<object>(values.Count);

            for (int i = 0; i < values.Count; i++)
            {
                foreach (var prop in values[i].GetType().GetProperties())
                {
                    row.Add(prop.GetValue(values[i], null));
                }
                data.Add(row);

                row = new List<object>(values.Count);
            }

            return data;
        }

        public async Task<IDirectResponseSchema> Export(string sheetName, IList values, int columnOffset = 1)
        {
            //await Task.WhenAll(initializingSpreadsheets);            

            var exportItem = _sheets.FirstOrDefault(c => c.SheetNames.FirstOrDefault(c => c.ToLower().Contains(sheetName.ToLower())) != null);

            if (exportItem == null)
            {
                Console.WriteLine($"Не удалось найти указанный лист Google Sheets: {sheetName}\n");

                return null;
            }

            var data = GetObjectList(values);

            return await PostData(data, sheetName, exportItem.SpreadsheetID, 1);
        }

        public async Task DeleteAll(string sheetName)
        {
            var exportItem = _sheets.FirstOrDefault(c => c.SheetNames.FirstOrDefault(c => c.ToLower().Contains(sheetName.ToLower())) != null);

            if (exportItem == null)
            {
                Console.WriteLine($"Не удалось найти указанный лист Google Sheets: {sheetName}\n");

                return;
            }
            var range = $"{sheetName}!A2:AAA";
            var requestBody = new ClearValuesRequest();
            var deleteRequest = googleSheetValues.Clear(requestBody, exportItem.SpreadsheetID, range);
            var response = deleteRequest.Execute();
        }

        private string GetA1Notation(int column, int columnsOffset = 1)
        {
            int columnsCount = column + columnsOffset - 1;
            string endColumn = string.Empty;
            int remainder = 0, divideResult = 0;
            do
            {
                divideResult = columnsCount / 25;
                remainder = columnsCount % 25;

                if (divideResult > 0) endColumn += "A";
                else endColumn += char.ToUpper((char)(64 + remainder));

                columnsCount -= 25;
            }
            while (divideResult > 0);

            return endColumn;
        }

        private async Task<AppendValuesResponse> PostData(List<IList<object>> data, string sheetName, string spreadsheetId, int firstColumnNum = 1)
        {
            int columnsCount = data.FirstOrDefault()?.Count ?? 0 + firstColumnNum;

            string firstColumn = GetA1Notation(firstColumnNum);

            string endColumn = GetA1Notation(columnsCount, firstColumnNum);

            if (columnsCount <= 0)
            {
                Console.WriteLine("При отправке данных на Google Sheets произошла ошибка: количество столбцов меньше ноля. Данные не были отправлены");
                return null;
            }

            try
            {
                var range = $"{sheetName}!{firstColumn}2:{endColumn}";
                var valueRange = new ValueRange
                {
                    Values = data
                };
                var appendRequest = googleSheetValues.Append(valueRange, spreadsheetId, range);
                appendRequest.ValueInputOption = AppendRequest.ValueInputOptionEnum.USERENTERED;
                var response = await appendRequest.ExecuteAsync();

                return response;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            return null;
        }
    }
}
