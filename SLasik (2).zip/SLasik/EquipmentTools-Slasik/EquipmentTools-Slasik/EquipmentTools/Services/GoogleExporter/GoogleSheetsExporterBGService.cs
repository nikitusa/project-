﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Requests;
using Google.Apis.Services;
using Google.Apis.Sheets.v4;
using Google.Apis.Sheets.v4.Data;
using HR_Transfers_WebAPI.Google;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using System;
using static Google.Apis.Sheets.v4.SpreadsheetsResource.ValuesResource;

namespace HR_Transfers_WebAPI.Services.GoogleSheets
{

    public class GoogleSheetsExporterBGService : BackgroundService
    {
        private IServiceProvider Provider { get; set; }

        private CancellationToken _token;

        public GoogleSheetsExporter Exporter { get; private set; }

        private List<TimeSlotAction<object>> actions;

        public SheetsService _sheetsService;

        public SheetsService SheetsService
        {
            get
            {
                if (_sheetsService == null)
                {
                    _sheetsService = new SheetsService(new BaseClientService.Initializer()
                    {
                        HttpClientInitializer = GoogleAuthentication.Login(
                        "1045168172166-8252afd2svev6d8h7gl8fsqvklb3eiia.apps.googleusercontent.com",
                        "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", new string[] { SheetsService.Scope.Spreadsheets }).Result
                    });
                }
                return _sheetsService;
            }
        }

        private SpreadsheetExportFactory shFactory;

        public GoogleSheetsExporterBGService(IServiceProvider provider)
        {
            Provider = provider;
            shFactory = new SpreadsheetExportFactory(SheetsService);

            var scope = Provider.CreateAsyncScope();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            Exporter = new GoogleSheetsExporter(Provider, SheetsService, new List<GoogleSheetsExporter.SpreadsheetExport>()
            {
                await shFactory.GetSpreadsheetExport("1peJmB7_u5srwycsF0WWwCdhRBcFDcLaIRBqA-Oiwj5o")
            });

            //ExportEmployees();

            actions = new List<TimeSlotAction<object>>()
            {
                //new TimeSlotAction<object>(new TimeSpan(9, 0, 10), async ()=>await ExportSubmissions(), stoppingToken)
            };
        }
    }
}

        //private async Task ExportSubmissions()
        //{
        //    await Exporter.DeleteAll("Все заявки");
        //    var result = await Exporter.Export("Все заявки", await transCtx.SubmissionStats.ToListAsync());
        //    if (((AppendValuesResponse)result).Updates.UpdatedRows > 0)
        //    {
        //        Console.WriteLine("Выгрузка HR Tools Все заявки\nБыло обновлено строк: " + ((AppendValuesResponse)result).Updates.UpdatedRows);
        //    }
        //    else Console.WriteLine("Выгрузка HR Tools Все заявки\nНе было добавлено строк");
        //}


/*
class GoogleSheetsExporterBGService : BackgroundService
{
    private IServiceProvider Provider { get; set; }
    public ILoggerService Logger { get; }

    public TimeSpan IntervalStart { get; set; } = new TimeSpan(9, 0, 0);
    public TimeSpan IntervalEnd { get; set; } = new TimeSpan(9, 20, 0);

    private TimeSpan IntervalDelay = TimeSpan.FromMinutes(15);

    SpreadsheetsResource.ValuesResource googleSheetValues { get; set; }

    SheetsService sheetsService { get; set; }

    private static string SPREADSHEET_ID = "1xiLLos_zpo-6JSBaPBYerWe-eyeNvQBvR7HSa4G_Cbo";

    private static string SHEET_NAME = "Все заявки";

    List<TimeSlotAction<AppendValuesResponse>> actions = new List<TimeSlotAction<AppendValuesResponse>>();

    public GoogleSheetsExporterBGService(IServiceProvider provider)
    {
        Provider = provider;
        using (var scope = Provider.CreateScope())
        {
            Logger = scope.ServiceProvider.GetRequiredService<ILoggerService>();

            try
            {
                sheetsService = new SheetsService(new BaseClientService.Initializer()
                {
                    HttpClientInitializer = GoogleAuthentication.Login(
                    "1045168172166-8252afd2svev6d8h7gl8fsqvklb3eiia.apps.googleusercontent.com",
                    "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", new string[] { SheetsService.Scope.Spreadsheets }).Result
                });
                googleSheetValues = sheetsService.Spreadsheets.Values;
            }
            catch (Exception ex)
            {
                Logger.LogError(ex.ToString());
            }
        }
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            if (DateTime.Now.TimeOfDay >= IntervalStart && DateTime.Now.TimeOfDay <= IntervalEnd)
            {
                await ExportSubmissionStatsView();
            }

            await Task.Delay(IntervalDelay);
        }
    }
    private async Task DeleteAll()
    {
        var range = $"{SHEET_NAME}!A2:J";
        var requestBody = new ClearValuesRequest();
        var deleteRequest = googleSheetValues.Clear(requestBody, SPREADSHEET_ID, range);
        var response = deleteRequest.Execute();
    }
    public async Task PostData(List<SubmissionStat> items)
    {
        List<IList<object>> data = new List<IList<object>>();
        try
        {
            foreach (var c in items)
            {
                data.Add(new List<object>() { c.Номер_заявки, c.ФИО_Ответственного, c.Должность_ответственного, c.ФИО_Сотрудника, c.Должность_сотрудника, c.Причина_аномалии, c.Дата_создания, c.Дата_начала, c.Дата_конца, c.Статус_одобрения, c.Статус_обработки });
            }
            var range = $"{SHEET_NAME}!A2:J";
            var valueRange = new ValueRange
            {
                Values = data
            };
            var appendRequest = googleSheetValues.Append(valueRange, SPREADSHEET_ID, range);
            appendRequest.ValueInputOption = AppendRequest.ValueInputOptionEnum.USERENTERED;
            var response = appendRequest.Execute();
        }
        catch (Exception ex)
        {
            Logger.LogError(ex.ToString());
        }
    }

    private async Task ExportSubmissionStatsView()
    {
        HRTRANSContext ctx;

        //if (sheetsService == null)
        //    try
        //    {
        //        sheetsService = new SheetsService(new BaseClientService.Initializer()
        //        {
        //            HttpClientInitializer = GoogleAuthentication.Login(
        //            "1045168172166-8252afd2svev6d8h7gl8fsqvklb3eiia.apps.googleusercontent.com",
        //            "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", new string[] { SheetsService.Scope.Spreadsheets }).Result
        //        });
        //        googleSheetValues = sheetsService.Spreadsheets.Values;
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.LogError(ex.ToString());
        //    }

        if (sheetsService == null) return;

        try
        {
            using (var scope = Provider.CreateScope())
            {
                ctx = scope.ServiceProvider.GetRequiredService<HRTRANSContext>();

                var data = await ctx.SubmissionStats.ToListAsync();

                await DeleteAll();

                await PostData(data);
            }
        }
        catch (Exception ex)
        {
            Logger.LogError(ex.ToString());
        }
    }
}
*/

