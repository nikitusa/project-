﻿using Google.Apis.Sheets.v4;
using static HR_Transfers_WebAPI.Services.GoogleSheets.GoogleSheetsExporter;

namespace HR_Transfers_WebAPI.Services.GoogleSheets
{
    public class SpreadsheetExportFactory
    {
        private readonly SheetsService _sheetsService;
        private readonly string _spreadsheetID;

        public SpreadsheetExportFactory(SheetsService sheetsService, string spreadsheetID = null)
        {
            _sheetsService = sheetsService;
            _spreadsheetID = spreadsheetID;
        }

        public async Task<SpreadsheetExport> GetSpreadsheetExport(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                return await (new SpreadsheetExport(id)).Initialize(_sheetsService);
            }
            else if (!string.IsNullOrEmpty(_spreadsheetID))
            {
                return await (new SpreadsheetExport(_spreadsheetID)).Initialize(_sheetsService);
            }
            else return null;
        }
    }
}
