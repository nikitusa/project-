﻿
using HrTemplate.Models.HrTemplateContext;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using System.Linq.Expressions;

namespace EquipmentTools.Services.HRTemplateServices
{
    public class EmployeesTSSService
    {
        public IDbContextFactory<HrTemplateContext> DbContextFactory { get; }
        public EmployeesTSSService(IDbContextFactory<HrTemplateContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }
    public async Task<Employee> GetEmployeeAsync(Expression<Func<Employee,bool>> predicate)
    {
        var ctx = await DbContextFactory.CreateDbContextAsync();
            if (predicate != null)
            {

                var result = await ctx.Employees.FirstOrDefaultAsync(predicate);

                return result;
            }
            else return null;
    }
    public async Task<List<Employee>> GetEmployeesAsync(Expression<Func<Employee,bool>> predicate)
    {
        var ctx = await DbContextFactory.CreateDbContextAsync();
            if (predicate != null)
            {

                var result = await ctx.Employees.Where(predicate).ToListAsync();

                return result;
            }
            else return null;
    }

    }
}
