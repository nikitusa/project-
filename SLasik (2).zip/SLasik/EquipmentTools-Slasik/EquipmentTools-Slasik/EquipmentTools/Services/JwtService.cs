﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace EquipmentTools.Services
{
    public class JwtService
    {
        public IConfiguration Configuration { get; set; }

        public JwtService(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IEnumerable<Claim> ParseClaims(string jwt)
        {
            var handler = new JwtSecurityTokenHandler();

            if (handler.CanReadToken(jwt))
            {
                var ValidIssuer = Configuration["Jwt:Issuer"];
                var ValidAudience = Configuration["Jwt:Audience"];
                var IssuerSigningKey = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]));
                var claimsPrincipal = handler.ValidateToken(jwt,
                    new Microsoft.IdentityModel.Tokens.TokenValidationParameters()
                    {
                        ValidIssuer = ValidIssuer,
                        ValidAudience = ValidAudience,
                        IssuerSigningKey = IssuerSigningKey
                    }, out var securityToken);

                if (claimsPrincipal != null)
                {
                    return claimsPrincipal.Claims;
                }
            }

            return null;
        }

        public string? GetUserToken(ClaimsPrincipal? user)
        {
            if (user is null) return null;
            var issuer = Configuration["Jwt:Issuer"];
            var audience = Configuration["Jwt:Audience"];
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var claimsList = user.Claims;

            var token = new JwtSecurityToken(
                issuer: issuer,
                audience: audience,
                signingCredentials: credentials,
                claims: claimsList, expires: DateTime.Now.AddMilliseconds(50)
                );
            var tokenHandler = new JwtSecurityTokenHandler();
            var stringToken = tokenHandler.WriteToken(token);

            return stringToken;
        }

        public ClaimsPrincipal ParseClaimsPrincipal(string jwt)
        {
            var handler = new JwtSecurityTokenHandler();

            if (handler.CanReadToken(jwt))
            {

                var claimsPrincipal = handler.ValidateToken(jwt,
                    new Microsoft.IdentityModel.Tokens.TokenValidationParameters()
                    {
                        ValidIssuer = Configuration["Jwt:Issuer"],
                        ValidAudience = Configuration["Jwt:Audience"],
                        IssuerSigningKey = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]))
                    }, out var securityToken);

                if (claimsPrincipal != null)
                {
                    return claimsPrincipal;
                }
            }

            return null;
        }
    }
}
