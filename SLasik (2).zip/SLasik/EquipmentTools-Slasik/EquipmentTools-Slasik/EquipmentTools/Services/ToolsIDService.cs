﻿using EquipmentTools.Data;
using EquipmentTools.Models.EquipmentContext;
using Google.Apis.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Newtonsoft.Json;
using System.Collections;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using IHttpClientFactory = System.Net.Http.IHttpClientFactory;

namespace EquipmentTools.Services
{
    public class ToolsIDService
    {
        private IDbContextFactory<EquipmentContext> DbContextFactory { get; }
        public IHttpClientFactory HttpClientFactory { get; }
        private ILogger<ToolsIDService> Logger { get; }

        private string Token { get; set; }

        private HttpClient HttpClient;

        public HttpClient ErrorHttpClient { get; }

        public ToolsIDService(IDbContextFactory<EquipmentContext> dbContextFactory, IHttpClientFactory httpClientFactory, ILogger<ToolsIDService> logger)
        {
            DbContextFactory = dbContextFactory;
            HttpClientFactory = httpClientFactory;
            Logger = logger;

            HttpClient = httpClientFactory.CreateClient("ToolsIDApiClient");

            HttpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            ErrorHttpClient = httpClientFactory.CreateClient("ErrorNotifierClient");
        }

        private async Task CheckToken()
        {
            if (Token == null)
            {
                Token = await GetToken();
            }
        }

        public void SetNewToken(string token)
        {
            if(!string.IsNullOrEmpty(token))
            {
                Token = token;
            }
        }

        public async Task<string> GetToken()
        {
            var tokenResponse = await HttpClient.PostAsync("/api/login?email=sklinkov@fmlogistic.com&password=FMlogistic01", null);
            var tokenResponseContent = await tokenResponse.Content.ReadAsStringAsync();
            var contentToken = "";

            dynamic tokenResponseObject = JsonConvert.DeserializeObject<dynamic>(tokenResponseContent);

            if (tokenResponseObject != null)
            {
                if ((bool)tokenResponseObject.success)
                {
                    contentToken = tokenResponseObject.data.token;
                    return contentToken;
                }
                else
                {
                    Logger.LogError("Не удалось получить токен ToolsID");
                }
            }
            return null;
        }


        public async Task<List<ToolsIDStatusMapping>> GetAllToolsIDStatuses()
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            var result = await ctx.ToolsIDStatusMappings.ToListAsync();
            return result;
        }

        public async Task<List<ToolsIDEmployeeDto>?> GetEmployees()
        {
            await CheckToken();

            var employeesResponse = await HttpClient.GetAsync("/api/thirdparty/employees");

            if (!employeesResponse.IsSuccessStatusCode)
            {
                return null;
            }

            List<ToolsIDEmployeeDto> employeeList = null;

            var employeesJson = await employeesResponse.Content.ReadAsStringAsync();

            dynamic employeesList = JsonConvert.DeserializeObject(employeesJson);

            if(employeesList == null)
            {
                Logger.LogError("Не удалось десериализовать список сотрудников");
                return null;
            }
            try
            {
                employeeList = ((IEnumerable)employeesList.list).Cast<dynamic>().Select(c => new ToolsIDEmployeeDto
                {
                    PersonnelID = c.ext_id,
                    BadgeKey = c.label,
                    PersonnelNumber = c.ext_login,
                    FirstName = c.firstname
                }).ToList();
                
            }
            catch (Exception ex)
            {

            }

            return employeeList;
        }

        public async Task<ToolsIDEquipmentDTO> GetToolsIDEquipmentAsync()
        {

            await CheckToken();
            var getUri = new Uri("http://90.156.205.169/api/thirdparty/equipment");
            HttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);

            try
            {
                var responce = await HttpClient.GetAsync(getUri);
                if (!responce.IsSuccessStatusCode)
                {
                    var message = await (new ErrorDto("Ошибка при обращении в ToolsID API", responseMessage: responce)).GetErrorMessage();
                    message = message.Replace("*", "Any");
                    var errorNotifyResponse = await ErrorHttpClient.PostAsJsonAsync("postError", message);
                    if (responce.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        Logger.LogInformation("Создан новый HttpClient для ToolsID API");
                        HttpClient = HttpClientFactory.CreateClient("ToolsIDApiClient");
                        HttpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        HttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);

                        if (!responce.IsSuccessStatusCode)
                        {
                            Logger.LogError("Не удалось получить список оборудования после создания нового HttpClient");
                            await ErrorHttpClient.PostAsJsonAsync("postError", await (new ErrorDto("Не удалось получить список оборудования после создания нового HttpClient", responseMessage: responce)).GetErrorMessage());
                            return null;
                        }
                    }
                }
                var content = await responce.Content.ReadAsStringAsync();

                var data = JsonConvert.DeserializeObject<ToolsIDEquipmentDTO>(content);

                return data;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.LogError($"Ошибка получения данных оборудования из ToolsID: {ex.ToString()}");
                return null;
            }
        }
    }
}
