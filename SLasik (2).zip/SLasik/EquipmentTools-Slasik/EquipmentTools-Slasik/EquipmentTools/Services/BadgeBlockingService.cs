﻿using Coravel.Invocable;
using EquipmentTools.Models.EquipmentContext;
using EquipmentTools.Services.BackgroundQueue;
using EquipmentTools.Services.EquipmentSerices;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using WMSLoginsAccounting.Policies;
using WMSLoginsAccounting.Services.PersonelDataService;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace EquipmentTools.Services
{
    public class BadgeBlockingService
    {
        public BadgeBlockingService(PersonelService personelService, ILogger<BadgeBlockingService> logger, EquipStatusChangesService equipStatusChangesService, IDatabaseRetryService databaseRetryService,
            IBackgroundTaskQueue backgroudTaskQueue)
        {
            PersonelService = personelService;
            Logger = logger;
            EquipStatusChangesService = equipStatusChangesService;
            DatabaseRetryService = databaseRetryService;
            BackgroudTaskQueue = backgroudTaskQueue;
        }

        private record LoginEquipmentInUse(string login, bool hasEquipmentInUse);

        public PersonelService PersonelService { get; }
        public ILogger<BadgeBlockingService> Logger { get; }
        public EquipStatusChangesService EquipStatusChangesService { get; }
        public IDatabaseRetryService DatabaseRetryService { get; }
        public IBackgroundTaskQueue BackgroudTaskQueue { get; }

        public async Task SetBadgeBlockAsync(EquipStatusChange statusChange)
        {
            var currentStatus = statusChange.CurrentStatusID;
            bool success = false;
            bool blocked = false;
            bool canUnblock = false;
            if (currentStatus != 1)
            {
                var loginStatusesQuery = await EquipStatusChangesService.GetEquipStatusChangesQueryAsync(null);

                loginStatusesQuery = loginStatusesQuery.TagWithCallSite();

                var loginStatuses = await loginStatusesQuery
                    .GroupBy(c => c.EquipID) // Группируем статусы по оборудованию
                    .Select(c => new EquipStatusChange
                    {
                        EquipStatusChangesID = c.Max(x => x.EquipStatusChangesID)
                    })
                    .Join(loginStatusesQuery.Where(c => c.Login == statusChange.Login)
                    .GroupBy(c => new
                    {
                        c.EquipID,
                        c.Login
                    })
                    // Группируем статусы по оборудованию
                    .Select(c => new EquipStatusChange
                    {
                        EquipStatusChangesID = c.Max(x => x.EquipStatusChangesID),
                        Login = c.Max(x => x.Login)

                    }), x => x.EquipStatusChangesID, c => c.EquipStatusChangesID, (x, c) => c)

                    .Join(loginStatusesQuery, c => c.EquipStatusChangesID, x => x.EquipStatusChangesID, (c, x) => new  // Соединяем чтобы взять доп даные
                    {
                        x.CurrentStatusID,
                        c.Login
                    })
                    .ToListAsync();
                // var a = loginStatusesQuery.Where(c => c.Login == statusChange.Login).Take(1).ToList();
                canUnblock = loginStatuses.Count(c => c.CurrentStatusID == 1) == 0;

            }
            if (currentStatus == 1)
            {

                await BackgroudTaskQueue.QueueBackgroundWorkItemAsync(async (a) =>

                await DatabaseRetryService.ExecutePipelineWithRetryAsync(async () =>
                {
                    success = await PersonelService.TryBlockBadgeBlockingAsync(statusChange.Login, a);
                    blocked = true;
                    Logger.LogInformation($"Бадж {statusChange.Login} {(success ? "" : "не")} удалось {(blocked ? "Заблокировать" : "разблокировать")}");
                }
                ));

            }
            else if (currentStatus != 1 && canUnblock)
            {
                await BackgroudTaskQueue.QueueBackgroundWorkItemAsync(async(a)=>
                
                await DatabaseRetryService.ExecutePipelineWithRetryAsync(async ()=>
                {
                    success = await PersonelService.TryUnblockBadgeBlockingAsync(statusChange.Login, a);
                    Logger.LogInformation($"Бадж {statusChange.Login} {(success ? "" : "не")} удалось {(blocked ? "Заблокировать" : "разблокировать")}");
                }
                ));

            }
            //Logger.LogInformation($"Бадж {statusChange.Login} {(success ? "" : "не")} удалось {(blocked ? "Заблокировать" : "разблокировать")}");

        }
        public async Task SetBadgeBlockListAsync(IEnumerable<EquipStatusChange> statusChanges)
        {
            bool success = false;
            bool blocked = false;
            bool canUnblock = false;

            var statusesNotInUse = statusChanges.Where(x => x.CurrentStatusID != 1);
            var statusesInUse = statusChanges.Where(x => x.CurrentStatusID == 1);

            List<LoginEquipmentInUse> loginsEquipmentInUseCount = null;
            try
            {


                if (statusesNotInUse.Count() > 0)
                {
                    var loginStatusesQuery = await EquipStatusChangesService.GetEquipStatusChangesQueryAsync(null);

                    loginStatusesQuery = loginStatusesQuery.TagWithCallSite();

                    loginsEquipmentInUseCount = await loginStatusesQuery
                        .GroupBy(c => c.EquipID) // Группируем статусы по оборудованию
                        .Select(c => new EquipStatusChange
                        {
                            EquipStatusChangesID = c.Max(x => x.EquipStatusChangesID)
                        })
                        .Join(loginStatusesQuery.Where(c => statusesNotInUse.Select(x => x.Login).Contains(c.Login))
                        .GroupBy(c => new
                        {
                            c.EquipID,
                            c.Login
                        })
                        // Группируем статусы по оборудованию
                        .Select(c => new EquipStatusChange
                        {
                            EquipStatusChangesID = c.Max(x => x.EquipStatusChangesID),
                            Login = c.Max(x => x.Login)

                        }), x => x.EquipStatusChangesID, c => c.EquipStatusChangesID, (x, c) => c)

                        .Join(loginStatusesQuery, c => c.EquipStatusChangesID, x => x.EquipStatusChangesID, (c, x) => new  // Соединяем чтобы взять доп даные
                        {
                            x.CurrentStatusID,
                            c.Login
                        })
                        .GroupBy(c => new { c.Login, c.CurrentStatusID }).Select(c => new LoginEquipmentInUse(c.Key.Login, c.Count(x=>x.CurrentStatusID == 1) > 0))
                        .ToListAsync();
                    // var a = loginStatusesQuery.Where(c => c.Login == statusChange.Login).Take(1).ToList();
                    //canUnblock = loginStatuses.Count(c => c.CurrentStatusID == 1) == 0;

                }
                if (statusesInUse.Any())
                {

                    await BackgroudTaskQueue.QueueBackgroundWorkItemAsync(async (a) =>

                    await DatabaseRetryService.ExecutePipelineWithRetryAsync(async () =>
                    {
                        var loginsToBlock = statusesInUse.Select(c => c.Login).ToList();
                        var notBlockedLogins = await PersonelService.TryBlockBadgesAsync(loginsToBlock, a);
                        var blockedLogins = loginsToBlock.Except(notBlockedLogins);
                        Logger.LogInformation($"Заблокированы логины: {String.Join(", ", blockedLogins)}");
                        blocked = true;
                        //Logger.LogInformation($"Бадж {statusChange.Login} {(success ? "" : "не")} удалось {(blocked ? "Заблокировать" : "разблокировать")}");
                    }
                    ));

                }
                if (loginsEquipmentInUseCount?.Any() ?? false)
                {
                    var loginsWithNoEquipmentInUse = loginsEquipmentInUseCount.DistinctBy(c=>c.login).Where(c => !c.hasEquipmentInUse);
                    await BackgroudTaskQueue.QueueBackgroundWorkItemAsync(async (a) =>

                    await DatabaseRetryService.ExecutePipelineWithRetryAsync(async () =>
                    {
                        var loginsToUnblock = loginsWithNoEquipmentInUse.Select(c => c.login).ToList();
                        var notUnblockedLogins = await PersonelService.TryUnblockBadgesAsync(loginsToUnblock, a);
                        var unblockedLogins = loginsToUnblock.Except(notUnblockedLogins);
                        Logger.LogInformation($"Разблокированы логины: {String.Join(", ", unblockedLogins)}");
                        //Logger.LogInformation($"Бадж {statusChange.Login} {(success ? "" : "не")} удалось {(blocked ? "Заблокировать" : "разблокировать")}");
                    }
                    ));

                }
                //Logger.LogInformation($"Бадж {statusChange.Login} {(success ? "" : "не")} удалось {(blocked ? "Заблокировать" : "разблокировать")}");
            }
            catch(Exception ex)
            {
                Logger.LogError(ex.ToString());
            }
        }

        private async ValueTask<T1> CreateBackgroundRetryTask<T1>(Task<T1> task)
        {
            return await task;
        }
    }
}
