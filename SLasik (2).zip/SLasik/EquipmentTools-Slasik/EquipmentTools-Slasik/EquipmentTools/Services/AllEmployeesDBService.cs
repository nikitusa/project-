﻿using EquipmentTools.Data;
using EquipmentTools.Models.EmployeesContext;
using EquipmentTools.Services.EmployeesService;
using EquipmentTools.Services.HRTemplateServices;
using Microsoft.EntityFrameworkCore;

namespace EquipmentTools.Services
{
    public class AllEmployeesDBService
    {
        private EmployeesService.EmployeesService OutsourcePersonnelService { get; set; }
        private EmployeesTSSService StaffMembersService { get; set; }
        private IDbContextFactory<EmployeesContext> LoginsDataContextFactory { get; }

        public AllEmployeesDBService(EmployeesService.EmployeesService outsourcePersonnelService, EmployeesTSSService staffMembersService, IDbContextFactory<EmployeesContext> loginsDataContextFactory)
        {
            OutsourcePersonnelService = outsourcePersonnelService;
            StaffMembersService = staffMembersService;
            LoginsDataContextFactory = loginsDataContextFactory;
        }

        public async Task<List<GeneralEmployee>> TryGetListEmployeesAsync(List<string> logins)
        {
            var outsourceQuery = await OutsourcePersonnelService.GetEmployeesFilteredAsync(c => logins.Contains(c.PersonnelNumber));

            var staff = await StaffMembersService.GetEmployeesAsync(c=>logins.Contains(c.PersonnelNumber));

            var outsourceGeneral = await outsourceQuery.Select(c=>new GeneralEmployee { FIO = c.FIO, PersonnelNumber = c.PersonnelNumber,Company = c.Employments.OrderBy(c=>c.EmploymentID).LastOrDefault().Company.CompanyName}).ToListAsync();
            var staffGeneral = staff.Select(c => new GeneralEmployee { FIO = $"{c.SecondName} {c.FirstName}", PersonnelNumber=c.PersonnelNumber,Company = "FM Logistic" });

            outsourceGeneral.AddRange(staffGeneral);

            return outsourceGeneral;
        }

        private async Task<GeneralEmployee?> TryGetOutsourcePersonnel(string value)
        {
            Employee outsourceEmployee = null;
            GeneralEmployee employee = null;
            if (value != null)
            {
                if (value.Contains("OUT-"))
                {
                    outsourceEmployee = await OutsourcePersonnelService.GetEmployeeAsync(c => c.PersonnelNumber == value);
                }
                if (outsourceEmployee != null)
                {
                    employee = new GeneralEmployee() { FIO = outsourceEmployee.FIO, PersonnelNumber = outsourceEmployee.PersonnelNumber };
                }
            }

            return employee;
        }

        private async Task<GeneralEmployee?> TryGetStaffMember(string value)
        {
            GeneralEmployee employee = null;
            if (value != null)
            {
                var staffMember = await StaffMembersService.GetEmployeeAsync(c => c.PersonnelNumber == value);
                if (staffMember != null)
                {
                    employee = new GeneralEmployee() { FIO = $"{staffMember.SecondName} {staffMember.FirstName} {staffMember.Patronymic}", PersonnelNumber = staffMember.PersonnelNumber };
                }
            }
            return employee;
        }

        public async Task<GeneralEmployee?> TryGetGeneralEmployee(string value)
        {
            GeneralEmployee? employee = null;

            if (string.IsNullOrEmpty(value)) return employee;

            employee = await TryGetOutsourcePersonnel(value);

            if (employee == null)
            {
                employee = await TryGetStaffMember(value);
            }

            return employee;
        }
        public async Task<GeneralEmployee?> TryGetTempBadgeOutsource(string tempBadgeNumber, long platformId = 1)
        {
            EmployeesContext ctx = await LoginsDataContextFactory.CreateDbContextAsync();

            var a = int.Parse(tempBadgeNumber);

            var issuance = await ctx.TemporaryBadgeIssuances.Where(c => c.BadgeNumber == a && c.PlatformID == platformId && c.IssuanceDate.Value.Date == DateTime.Now.Date)
                .OrderByDescending(c => c.IssuanceDate)
                .Include(c => c.Employee)
                .ThenInclude(c => c.Employments)
                .ThenInclude(c => c.Company)
                .Include(c => c.Employee)
                .ThenInclude(c => c.Employments)
                .Take(1)
                .FirstOrDefaultAsync();

            if (issuance == null) return null;

            return new GeneralEmployee() { FIO = issuance.Employee.FIO, Company = issuance.Employee.Employments.OrderBy(c => c.EmploymentID).LastOrDefault().Company.CompanyName, PersonnelNumber = issuance.Employee.PersonnelNumber };
        }
    }
}
