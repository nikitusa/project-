﻿using EquipmentTools.Data;

namespace EquipmentTools.Services
{
    public class EventsService
    {
        public enum EventType
        {
            EquipmentRegister, EquipmentTransfer, EquipmentInventoryCreated, EquipmentInventoryClosed
        }

        public EventHandler Event { get; set; }

        public async Task InvokeEvent(string name)
        {
            Event?.Invoke(name, EventArgs.Empty);
        }

        public async Task InvokeEvent(EventType type)
        {
            Event?.Invoke(type, EventArgs.Empty);
        }
        public async Task InvokeEvent(EventData data)
        {
            Event?.Invoke(data, EventArgs.Empty);
        }
    }
}
