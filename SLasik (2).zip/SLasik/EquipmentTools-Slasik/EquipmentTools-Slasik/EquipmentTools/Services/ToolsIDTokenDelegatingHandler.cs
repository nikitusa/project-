﻿using EquipmentTools.Data;
using System.Net.Http.Headers;

namespace EquipmentTools.Services
{
    public class ToolsIDTokenDelegatingHandler : DelegatingHandler
    {

        private UserService _userService;

        private string _token;

        public ToolsIDTokenDelegatingHandler(IServiceProvider provider, ILogger<ToolsIDTokenDelegatingHandler> logger)
        {
            Provider = provider;
            Logger = logger;
        }

        public ToolsIDService ToolsIDService { get; set; }
        public IServiceProvider Provider { get; }
        public ILogger<ToolsIDTokenDelegatingHandler> Logger { get; }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            if(ToolsIDService is null)
            {
                ToolsIDService = Provider.CreateAsyncScope().ServiceProvider.GetRequiredService<ToolsIDService>();
            }

            var response = await base.SendAsync(request, cancellationToken);

            if(response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                var newToken = await ToolsIDService.GetToken();
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", newToken); 
                response = await base.SendAsync(request, cancellationToken);

                if (response.IsSuccessStatusCode)
                {
                    ToolsIDService.SetNewToken(newToken);
                    Logger.LogInformation("Установлен новый токен для сервиса ToolsID");
                }
                else
                {
                    Logger.LogError("Не удалось установить подключение к ToolsID API после установки нового токена");
                }
            }

            if (!response.IsSuccessStatusCode)
            {
                
                Logger.LogError($"Произошла ошибка при обращении к ToolsID: статус код {response.StatusCode},{await request.WriteRequestToString()}");
            }

            return response;
        }
    }
}
