﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Newtonsoft.Json.Linq;
using System.Linq.Expressions;
using WMSLoginsAccounting.Models.PersonnelFirebirdContext;
using WMSLoginsAccounting.Models.TssPersonnelModel;

namespace WMSLoginsAccounting.Services.PersonelDataService
{

    public class PersonelService
    {
        public IDbContextFactory<PersonnelFirebirdContext> DbContextFactory { get; set; }

        public ILogger<PersonelService> Logger { get; }
        private CancellationToken Token { get; set; }

        public PersonelService(IDbContextFactory<PersonnelFirebirdContext> dbContextFactory, ILogger<PersonelService> logger)
        {
            DbContextFactory = dbContextFactory;
            Logger = logger;
        }

        public async Task<bool> TryBlockBadgeBlockingAsync(string personnelNumber, CancellationToken? token = null)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync(token ?? CancellationToken.None);
            var employee = await ctx.Personnel.AsTracking().Select(c => new PersonnelModel
            {
                PersonnelID = c.PersonnelID,
                FIO = c.FIO,
                MARSRUT = c.MARSRUT,
                PersonnelNumber = c.PersonnelNumber
            }).FirstOrDefaultAsync(c => c.PersonnelNumber == personnelNumber, token ?? CancellationToken.None);

            if (employee == null) { return false; }

            if (employee.MARSRUT.Contains(",12"))
            {
                employee.MARSRUT = employee.MARSRUT.Replace(",12", "");
                await ctx.Personnel.Where(c => c.PersonnelID == employee.PersonnelID).ExecuteUpdateAsync(c => c.SetProperty(s => s.MARSRUT, s => s.MARSRUT.Replace(",12", "")));
                //await ctx.SaveChangesAsync(token ?? CancellationToken.None);
                return true;

            }
            if (employee.MARSRUT.StartsWith("12,"))
            {
                employee.MARSRUT = employee.MARSRUT.Replace("12,", "");
                await ctx.SaveChangesAsync(token ?? CancellationToken.None);
                return true;
            }
            else return false;
        }

        public async Task<bool> TryUnblockBadgeBlockingAsync(string personnelNumber, CancellationToken? token = null)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync(token ?? CancellationToken.None);
            var employee = await ctx.Personnel.AsTracking().Select(c => new PersonnelModel
            {
                PersonnelID = c.PersonnelID,
                FIO = c.FIO,
                MARSRUT = c.MARSRUT,
                PersonnelNumber = c.PersonnelNumber
            }).FirstOrDefaultAsync(c => c.PersonnelNumber == personnelNumber, token ?? CancellationToken.None);

            if (employee == null) { return false; }

            if (!employee.MARSRUT.Contains("12") && employee.MARSRUT != "0" && employee.MARSRUT != "1")
            {
                employee.MARSRUT = employee.MARSRUT + ",12";
                await ctx.Personnel.Where(c => c.PersonnelID == employee.PersonnelID).ExecuteUpdateAsync(c => c.SetProperty(s => s.MARSRUT, s => s.MARSRUT + ",12"));

                //await ctx.SaveChangesAsync(token ?? CancellationToken.None);
                return true;
            }
            else return false;
        }

        /// <summary>
        /// Убирает маршрут прохода через КПП у сотрудников с указанным табельным/идентификационным номером и возвращает список сотрудников которых невозможно заблокировать
        /// </summary>
        /// <param name="personnelNumber">Список табельных/идентификационных номеров</param>
        /// <param name="token"></param>
        /// <returns></returns>
        public async Task<IEnumerable<string>> TryBlockBadgesAsync(IEnumerable<string> personnelNumber, CancellationToken? token = null)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync(token ?? CancellationToken.None);

            List<PersonnelModel> employeesWithoutRoute = new();

            var employeesWithoutRouteQuery = ctx.Personnel.Where(c => personnelNumber.Contains(c.PersonnelNumber)).Where(c => !c.MARSRUT.Contains("12") || c.PersonnelNumber == "").Select(c => new PersonnelModel
            {
                PersonnelID = c.PersonnelID,
                FIO = c.FIO,
                MARSRUT = c.MARSRUT,
                PersonnelNumber = c.PersonnelNumber
            });

            try
            {
                employeesWithoutRoute = await employeesWithoutRouteQuery.ToListAsync();
            }
            catch (Exception ex)
            {
                Logger.LogError($"Произошла ошибка при запросе в FireBird {nameof(TryBlockBadgesAsync)}. Запрос: {employeesWithoutRouteQuery.ToString()}; Исключение: {ex.ToString()}");
            }

            var blockedBadgesCount = await ctx.Personnel.Where(c => personnelNumber.Contains(c.PersonnelNumber) && c.PersonnelNumber != "" && c.MARSRUT.Contains(",12")).ExecuteUpdateAsync(c => c.SetProperty(x => x.MARSRUT, x => x.MARSRUT.Replace(",12", "")));

            blockedBadgesCount += await ctx.Personnel.Where(c => personnelNumber.Contains(c.PersonnelNumber) && c.PersonnelNumber != "" && c.MARSRUT.Contains("12,")).ExecuteUpdateAsync(c => c.SetProperty(x => x.MARSRUT, x => x.MARSRUT.Replace("12,", "")));

            return employeesWithoutRoute.Select(c=>c.PersonnelNumber);
        }

        /// <summary>
        /// Добавляет маршрут прохода через КПП у сотрудников с указанным табельным/идентификационным номером и возвращает список сотрудников которых невозможно разблокировать или уже имеют маршрут прохода через КПП
        /// </summary>
        /// <param name="personnelNumber">Список табельных/идентификационных номеров</param>
        /// <param name="token"></param>
        /// <returns></returns>
        public async Task<IEnumerable<string>> TryUnblockBadgesAsync(IEnumerable<string> personnelNumber, CancellationToken? token = null)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync(token ?? CancellationToken.None);

            List<PersonnelModel> employeesWithRoute = new();

            var employeesWithRouteQuery = ctx.Personnel.Where(c => personnelNumber.Contains(c.PersonnelNumber)).Where(c => c.MARSRUT.Contains("12") || c.PersonnelNumber == "" || c.MARSRUT == "0" || c.MARSRUT == "1").Select(c => new PersonnelModel
            {
                PersonnelID = c.PersonnelID, FIO = c.FIO, MARSRUT = c.MARSRUT, PersonnelNumber = c.PersonnelNumber
            });

            try
            {
                employeesWithRoute = await employeesWithRouteQuery.ToListAsync();
            }
            catch(Exception ex)
            {
                Logger.LogError($"Произошла ошибка при запросе в FireBird {nameof(TryUnblockBadgesAsync)}.Логины:{String.Join(", ", personnelNumber)}\n Запрос: {employeesWithRouteQuery.ToString()}; Исключение: {ex.ToString()}");
            }

            var unblockedBadgesCount = await ctx.Personnel.Where(c => personnelNumber.Contains(c.PersonnelNumber) && c.PersonnelNumber != "" && !c.MARSRUT.Contains("12") && c.MARSRUT != "1" && c.MARSRUT != "0").ExecuteUpdateAsync(c => c.SetProperty(x => x.MARSRUT, x => x.MARSRUT + ",12"));

            return employeesWithRoute.Select(c=>c.PersonnelNumber);
        }

        public async Task<PersonnelModel> AddEmployeeAsync(PersonnelModel personnelModel)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            var empl = ctx.Personnel.Add(personnelModel);
            await ctx.SaveChangesAsync();
            return empl.Entity;
        }
        public async Task<List<PersonnelModel>> AddEmployeesAsync(List<PersonnelModel> personnelModel)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            if (!await ctx.Database.CanConnectAsync())
            {
                //throw new IOException("Невозможно подключиться с предоставленным контекстом");
                Logger.LogWarning("Невозможно подключиться с предоставленным контекстом");
                return null;
            }
            ctx.Personnel.AttachRange(personnelModel);
            await ctx.SaveChangesAsync();
            return personnelModel;
        }
        public async Task<PersonnelModel> UpdateEmployeesAsync(PersonnelModel personnelModel)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            var empl = await ctx.Personnel.FirstOrDefaultAsync(c => c.PersonnelID == personnelModel.PersonnelID);
            if (empl != null)
            {
                empl.PersonnelNumber = personnelModel.PersonnelNumber;
                empl.FIO = personnelModel.FIO;
                empl.QR_TABEL = personnelModel.QR_TABEL;
                await ctx.SaveChangesAsync();
                return empl;
            }
            return null;
            //var empl = ctx.Personnel.Update(personnelModel); ;
            //await ctx.SaveChangesAsync();
            //return empl.Entity;
        }

        public async Task<bool> CheckEmployeeExists(PersonnelModel? personnel)
        {
            if (personnel is null) throw new NullReferenceException();


            var ctx = await DbContextFactory.CreateDbContextAsync();
            var exists = (await ctx.Personnel.Select(c => new PersonnelModel { PersonnelNumber = c.PersonnelNumber }).FirstOrDefaultAsync(c => c.PersonnelNumber == personnel.PersonnelNumber) == null) ? false : true;

            return exists;
        }

        public async Task<List<PersonnelModel>> GetExistingEmployeesAsync(List<PersonnelModel> employees)
        {
            if (employees == null) throw new NullReferenceException();

            var ctx = await DbContextFactory.CreateDbContextAsync();

            if (employees.Count > 0)
            {
                var personnelNumbers = employees.Select(c => c.PersonnelNumber).ToList();

                var existingEmployees = await ctx.Personnel
                    .Where(c => personnelNumbers.Contains(c.PersonnelNumber))
                    .Select(c => new PersonnelModel { PersonnelNumber = c.PersonnelNumber })
                    .ToListAsync();

                return existingEmployees;
            }
            else return employees;
        }

        public async Task<IEnumerable<PersonnelModel>> GetPersonnelEmplAsync(Expression<Func<PersonnelModel, bool>> expression)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            var query = ctx.Personnel.Where(expression);
            return await query.ToListAsync();
        }

    }
}

