﻿using EquipmentTools.Models.EmployeesContext;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace EquipmentTools.Services.EmployeesService
{
    public class EmployeesService
    {
        public IDbContextFactory<EmployeesContext> DbContextFactory { get; }
        public EmployeesService(IDbContextFactory<EmployeesContext> dbContextFactory)
        {
            DbContextFactory = dbContextFactory;
        }
        public async Task<IQueryable<Employee>> GetEmployeesFilteredAsync(Expression<Func<Employee, bool>> predicate, params string[] includes)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();

            var query = ctx.Employees.AsQueryable();

            query = includes.Aggregate(query, (current, includePropery) => current.Include(includePropery));
            if (predicate != null)
            {
                query = query.Where(predicate);
            }


            return query;
        }
        public async Task<Employee> GetEmployeeAsync(Expression<Func<Employee,bool>> predicate,params string[] includes)
        {
            var ctx = await DbContextFactory.CreateDbContextAsync();
            var query = ctx.Employees.AsQueryable();
            query = includes.Aggregate(query, (current, includePropery) => current.Include(includePropery));
            if (predicate != null)
            {
                var employee = await query.FirstOrDefaultAsync(predicate);
                return employee;
            }
            else return null;
        }

    }
    
}
