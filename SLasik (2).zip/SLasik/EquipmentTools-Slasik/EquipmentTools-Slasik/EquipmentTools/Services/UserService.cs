﻿using System.Security.Claims;

namespace EquipmentTools.Services
{
    public class UserService
    {
        private JwtService _jwtService;

        public string Token { get; set; }
        public IHttpContextAccessor Accessor { get; set; }

        public UserService(IHttpContextAccessor accessor, IServiceProvider provider)
        {
            using (var scope = provider.CreateAsyncScope())
            {
                _jwtService = scope.ServiceProvider.GetRequiredService<JwtService>();
            }

            Accessor = accessor;
        }

        public string GetUserToken()
        {
            //if (string.IsNullOrEmpty(Token))
            {
                Token = _jwtService.GetUserToken(GetUser()) ?? "";
            }

            return Token;
        }

        public ClaimsPrincipal? GetUser()
        {
            return Accessor.HttpContext?.User;
        }
    }
}
