﻿using EquipmentTools.Data;
using EquipmentTools.Models.EquipmentContext;
using EquipmentTools.Schedulling;
using EquipmentTools.Services;
using EquipmentTools.Services.EquipmentSerices;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography.Xml;
using WMSLoginsAccounting.Services.PersonelDataService;

namespace EquipmentTools.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ToolsIDStatusChangeController : ControllerBase
    {
        public ToolsIDStatusChangeController(BadgeBlockingService badgeBlockingService,EquipmentUnitsService equipmentUnitsService, EquipStatusChangesService equipStatusChangesService, PersonelService personelService, AllEmployeesDBService allEmployeesDBService, ToolsIDService toolsIDService, ILogger<ToolsIDStatusChangeController> logger, EquipmentTransfersService transfersService, EventsService eventsService)
        {
            EquipmentUnitsService = equipmentUnitsService;
            EquipStatusChangesService = equipStatusChangesService;
            PersonelService = personelService;
            AllEmployeesDBService = allEmployeesDBService;
            ToolsIDService = toolsIDService;
            Logger = logger;
            TransfersService = transfersService;
            EventsService = eventsService;
            BadgeBlockingService = badgeBlockingService;
        }

        public EquipmentUnitsService EquipmentUnitsService { get; }
        public EquipStatusChangesService EquipStatusChangesService { get; }
        public PersonelService PersonelService { get; }

        public BadgeBlockingService BadgeBlockingService { get; }
        public AllEmployeesDBService AllEmployeesDBService { get; }
        public ToolsIDService ToolsIDService { get; }
        public ILogger<ToolsIDStatusChangeController> Logger { get; }
        public EquipmentTransfersService TransfersService { get; }
        public EventsService EventsService { get; }

        public static readonly int GAEcomClientActivity = 59;

        [HttpPost]
        public async Task<IActionResult> Post(IncomingEquipmentDto? equipment)
        {
            string badgeKey = string.Empty, login = string.Empty;

            EventData eventData = new EventData() { EventType = EventsService.EventType.EquipmentRegister};

            if(equipment == null || string.IsNullOrEmpty(equipment.serial))
            {
                Logger?.LogError("");
                return Ok();
            }

            var toolsStatusesMapping = await ToolsIDService?.GetAllToolsIDStatuses();           

            var unit = await EquipmentUnitsService.GetUnitAsync(equipment.serial);

            if(unit == null)
            {
                Logger?.LogError($"Серийный номер оборудования из шкафа не найден в БД EquipmentTools\n:{equipment.ToString()}");
                return Ok();
            }

            badgeKey = (equipment.location?.Contains("метка: ") ?? false) ? (equipment.location?.Split("метка: ", 2).LastOrDefault()) : null;

            var newStatusMapping = toolsStatusesMapping.FirstOrDefault(c => c.ToolsIDStatusID == equipment.new_state);

            if(newStatusMapping == null)
            {
                Logger?.LogError($"Маппинг не найден для статуса оборудования ToolsID: {equipment.new_state}");
                return Ok();
            }

            if (string.IsNullOrEmpty(badgeKey))
            {
                if (newStatusMapping.EquipmentStatusID == 2) login = unit.EquipStatusChanges.Last().Login;
                else
                {
                    login = "TKV00-0000";

                    var unblockStatus = new EquipStatusChange() { Login = unit.EquipStatusChanges.Last().Login, CurrentStatusID = 2 };
                    await BadgeBlockingService.SetBadgeBlockAsync(unblockStatus);
                }
            }
            else
            {
                var employees = await ToolsIDService.GetEmployees();
                var employee = employees.FirstOrDefault(c => c.BadgeKey == badgeKey);

                if (employee == null)
                {
                    Logger?.LogError($"Сотрудник по метке {badgeKey} не найден в ToolsID");
                    return BadRequest();
                }

                if (string.IsNullOrEmpty(employee.PersonnelNumber) && int.TryParse(employee.FirstName, out var badgeNumber))
                {
                    var generalEmpl = new GeneralEmployee();
                    generalEmpl = await AllEmployeesDBService.TryGetTempBadgeOutsource(employee.FirstName);

                    if(generalEmpl is null)
                    {
                        Logger.LogWarning("Временный бадж не найден по метке");
                        return BadRequest();
                    }

                    if (string.IsNullOrEmpty(generalEmpl.PersonnelNumber))
                    {
                        ArgumentException exception = new ArgumentException("Сотрудника нет в базе данных");
                    }
                    login = generalEmpl.PersonnelNumber;
                }
                else if (!string.IsNullOrEmpty(employee.PersonnelNumber))
                {
                    login = employee.PersonnelNumber;
                }
            }

            var newStatus = new EquipStatusChange() { EquipID = unit.EquipmentUnitsID, ClientActivityID = 59, CurrentStatusID = newStatusMapping.EquipmentStatusID.Value, DateTimeChanged = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Local), Login = login };

            var lastTransfer = await TransfersService.GetCurrentTransfer(unit.EquipmentUnitsID, "ClientActivity.Client", "ClientActivity.Activity");

            if (lastTransfer != null && lastTransfer.ClientActivityID != GAEcomClientActivity || lastTransfer == null && unit.ClientActivityID != GAEcomClientActivity)
            {
                var transfer = new EquipmentTransfer()
                {
                    UnitID = unit.EquipmentUnitsID,
                    ClientActivityID = GAEcomClientActivity,
                    LoginID = login,
                    Return = unit.ClientActivityID == GAEcomClientActivity ? true : false
                };

                await TransfersService.SetTransferEquipment(transfer);
                eventData.TargetAcitivityIDS.Add(GAEcomClientActivity);
                eventData.TargetAcitivityIDS.Add(lastTransfer == null ? (int)unit.ClientActivityID : (int)lastTransfer.ClientActivityID);
            }

            await EquipStatusChangesService.SetEquipStatusAsync(newStatus);
            await BadgeBlockingService.SetBadgeBlockAsync(newStatus);
            await EventsService.InvokeEvent(eventData);

            return Ok();
        }
    } 
}
