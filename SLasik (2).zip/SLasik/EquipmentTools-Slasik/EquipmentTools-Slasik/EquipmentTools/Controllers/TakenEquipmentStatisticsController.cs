﻿using EquipmentTools.Models.EquipmentContext;
using EquipmentTools.Data;
using EquipmentTools.Services;
using EquipmentTools.Services.EquipmentSerices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WMSLoginsAccounting.Services.PersonelDataService;

namespace EquipmentTools.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TakenEquipmentStatisticsController : ControllerBase
    {
        public TakenEquipmentStatisticsController(EquipmentUnitsService equipmentUnitsService, PersonelService personelService, AllEmployeesDBService allEmployeesDBService)
        {
            EquipmentUnitsService = equipmentUnitsService;
            PersonelService = personelService;
            AllEmployeesDBService = allEmployeesDBService;
        }

        public EquipmentUnitsService EquipmentUnitsService { get; }
        public PersonelService PersonelService { get; }
        public AllEmployeesDBService AllEmployeesDBService { get; }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var query = await EquipmentUnitsService.GetUnitsQueryAsync("Model.TypeNavigation", "ClientActivity.Client", "ClientActivity.Activity", "EquipStatusChanges.CurrentStatus", "EquipmentTransfers.ClientActivity.Client");
            query = query.Include(c => c.Model.TypeNavigation);
            query = query.Include(c => c.ClientActivity.Client);
            query = query.Include(c => c.ClientActivity.Activity);
            query = query.Include(c => c.EquipStatusChanges).ThenInclude(c => c.CurrentStatus);
            query = query.Where(c => c.EquipStatusChanges.OrderBy(x => x.EquipStatusChangesID).LastOrDefault().CurrentStatusID == 1);
            query = query.Select(c => new EquipmentUnit()
            {
                EquipmentUnitsID = c.EquipmentUnitsID,
                SerialNumber = c.SerialNumber,
                ClientActivity = c.ClientActivity,
                Model = new EquipmentModel() { Model = c.Model.Model, ModelsID = c.Model.ModelsID, Type = c.Model.Type, TypeNavigation = c.Model.TypeNavigation },
                EquipStatusChanges = new List<EquipStatusChange>() { c.EquipStatusChanges.OrderBy(c => c.EquipStatusChangesID).LastOrDefault() },
                EquipmentTransfers = new List<EquipmentTransfer>() { c.EquipmentTransfers.OrderBy(x => x.EquipmentTransfersID).LastOrDefault() }
            });
            query = query.OrderBy(c => c.EquipmentUnitsID);
            try
            {
                var list = await query.ToListAsync();

                var tempQuery = query;
                var blockedEquip = list.Select(c => new
                {
                    Client = c.ClientActivity.Client.ClientName,
                    Model = c.Model.Model,
                    SerialNumber = c.SerialNumber,
                    EquipmentType = c.Model.TypeNavigation.Type,
                    TabelNum = c.EquipStatusChanges.FirstOrDefault()?.Login,
                    DateTimeTaken = c.EquipStatusChanges.LastOrDefault()?.DateTimeChanged ?? default,
                    CurrentClient = c.EquipStatusChanges.LastOrDefault()?.ClientActivity.Client.ClientName

                }).ToList();

                var users = await AllEmployeesDBService.TryGetListEmployeesAsync(blockedEquip.Select(x => x.TabelNum).ToList());

                var loginBlockedList = blockedEquip.Join(users, c => c.TabelNum, x => x.PersonnelNumber, (x, c) => new EquipmentLoginsBlocked
                {
                    Client = x.Client,
                    Model = x.Model,
                    SerialNumber = x.SerialNumber,
                    EquipmentType = x.EquipmentType,
                    TabelNum = x.TabelNum,
                    FIO = c.FIO,
                    Company = c.Company,
                    DateTimeTaken = TimeZoneInfo.ConvertTimeFromUtc(x.DateTimeTaken, TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time")).ToString("dd.MM.yyyy HH:mm:ss"),
                    CurrentClient = x.CurrentClient
                }).OrderByDescending(c => c.DateTimeTaken).ToList();

                return Ok(loginBlockedList);
            }
            catch (Exception ex)
            {

            }

            return null;
        }
    }
}
