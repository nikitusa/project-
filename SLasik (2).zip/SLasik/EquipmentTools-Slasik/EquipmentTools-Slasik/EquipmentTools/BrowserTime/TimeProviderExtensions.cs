﻿using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components;

namespace EquipmentTools.BrowserTime
{
    public static class TimeProviderExtensions
    {
        public static DateTime? ToLocalDateTime(this TimeProvider timeProvider, DateTime? dateTime)
        {
            return dateTime.GetValueOrDefault().Kind switch
            {
                DateTimeKind.Unspecified => throw new InvalidOperationException("Unable to convert unspecified DateTime to local time"),
                DateTimeKind.Local => dateTime,
                _ => DateTime.SpecifyKind(TimeZoneInfo.ConvertTimeFromUtc(dateTime.GetValueOrDefault(), timeProvider.LocalTimeZone), DateTimeKind.Local),
            };
        }

        public static DateTime ToLocalDateTime(this TimeProvider timeProvider, DateTimeOffset dateTime)
        {
            var local = TimeZoneInfo.ConvertTimeFromUtc(dateTime.UtcDateTime, timeProvider.LocalTimeZone);
            local = DateTime.SpecifyKind(local, DateTimeKind.Local);
            return local;
        }
    }

   
}
