﻿namespace EquipmentTools.BrowserTime
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddBrowserTimeProvider(this IServiceCollection services)
            => services.AddScoped<BrowserTimeProvider>();
    }
}