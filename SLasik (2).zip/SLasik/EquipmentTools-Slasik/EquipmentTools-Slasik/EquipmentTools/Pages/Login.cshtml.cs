using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Claims;
using System.Text.Json;
using System.Text;
using EquipmentTools.Services;
using EquipmentTools.Data;
using Microsoft.AspNetCore.Components.Server.ProtectedBrowserStorage;
using EquipmentTools.Services.InfoServices;

namespace EquipmentTools.Pages
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        public User Credentials { get; set; }

        public JwtService JwtServiceParser { get; set; }
        public IHttpClientFactory HttpFactory { get; set; }
        public ProtectedLocalStorage LocalStorage { get; }
        public ClientActivityService ClientActivityService { get; }

        public LoginModel(JwtService jwtService, IHttpClientFactory httpFactory, ProtectedLocalStorage localStorage, ClientActivityService clientActivityService)
        {
            JwtServiceParser = jwtService;
            HttpFactory = httpFactory;
            LocalStorage = localStorage;
            ClientActivityService = clientActivityService;
        }

        public async Task<IActionResult> OnGetAsync()
        {
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(string username, string password)
        {
            int clientActivityId = 0;
            EmployeeDto employee = null;

            if (ModelState.IsValid)
            {
                Credentials.UserName = username;
                Credentials.Password = password;
                var content = System.Text.Json.JsonSerializer.Serialize(Credentials);
                var bodyContent = new StringContent(content, Encoding.UTF8, "application/json");

                using (HttpClient identityHttp = HttpFactory.CreateClient("IdentityApiClient"))
                {
                    using (HttpClient employeesClient = HttpFactory.CreateClient("SubmissionsApiClient"))
                    {

                        HttpResponseMessage response = null;
                        try
                        {
                            response = await identityHttp.PostAsync("gettoken", bodyContent);
                        }
                        catch (Exception ex)
                        {
                            ViewData["Error"] = $"��������� ������ ��� �����: \n ������ ����������� ����������";
                            return Page();
                        }

                        if (!response.IsSuccessStatusCode)
                        {
                            ViewData["Error"] = $"��������� ������ ��� �����: \n{await response.Content.ReadAsStringAsync()}";
                            return Page();
                        }

                        var authContent = await response.Content.ReadAsStringAsync();
                        var result = System.Text.Json.JsonSerializer.Deserialize<LoginResult>(authContent, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                        if (result?.Success ?? false)
                        {
                            var userIdentity = new ClaimsPrincipal(new ClaimsIdentity(JwtServiceParser.ParseClaims(result.Token), CookieAuthenticationDefaults.AuthenticationScheme));
                            bool hasEmplId = int.TryParse(userIdentity.Claims.FirstOrDefault(c => c.Type == "employeeid")?.Value, out var employeeId);
                            if (hasEmplId)
                            {
                                HttpResponseMessage employeeResponse = null;
                                try
                                {
                                    employeeResponse = await employeesClient.GetAsync($"employees/{employeeId}");
                                }
                                catch (Exception ex)
                                {
                                    ViewData["Error"] = "������ ������ � ����������� ����������";
                                    return Page();
                                }
                                if (employeeResponse != null && employeeResponse.IsSuccessStatusCode)
                                {
                                    employee = await employeeResponse.Content.ReadFromJsonAsync<EmployeeDto>();
                                    userIdentity.Identities.First().AddClaim(new Claim("positionid", employee.PositionID.ToString()));
                                    userIdentity.Identities.First().AddClaim(new Claim("platformid", employee.PlatformID.ToString()));
                                    userIdentity.Identities.First().AddClaim(new Claim("clientid", employee.ClientID.ToString()));
                                }
                            }

                            await HttpContext.SignInAsync(userIdentity);

                            var positionClaim = userIdentity.Claims.FirstOrDefault(c => c.Type == "positionid");
                            
                            return Redirect(Url.Content("/"));
                        }
                        else
                        {
                            ViewData["Error"] = "\t�������� ����� ��� ������";
                            return Page();
                        }

                    }
                }
            }

            return Page();
        }
    }
}
