﻿using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Claims;
using WMSLoginsAccounting.Models.TssPersonnelModel;

namespace WMSLoginsAccounting.Models.PersonnelFirebirdContext
{
    public class PersonnelFirebirdContext : DbContext
    {
        public virtual DbSet<PersonnelModel> Personnel { get; set; }
        public IConfiguration Configuration { get; }

        int platformId = 0;

        [ActivatorUtilitiesConstructor]
        public PersonnelFirebirdContext(DbContextOptions<PersonnelFirebirdContext> options)
        : base(options)
        {

        }

        public PersonnelFirebirdContext(string connectionString):base(new DbContextOptionsBuilder().UseFirebird(connectionString).Options)
        {
        }

        //public PersonnelFirebirdContext(IConfiguration configuration, IServiceProvider serviceProvider)
        //{
        //    var scope = serviceProvider.CreateScope();
        //    //var a = scope.ServiceProvider.GetRequiredService<IHttpContextAccessor>();
        //    //var state = a.HttpContext;

        //    //int.TryParse(state.User.FindFirstValue("platformid"), out platformId);

        //    Configuration = configuration;
        //}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PersonnelModel>(entity =>
            {
                entity.Property(e => e.FirstName).HasColumnName("FIRSTNAME").HasConversion<string?>();
            });
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = string.Empty;
            //switch (platformId)
            //{
            //    case 1:
            //        connectionString = Configuration.GetConnectionString("FirebirdPersonnel");
            //        break;
            //    default:
            //        break;
            //}
            connectionString = "User=SYSDBA;Password=masterkey;Database=C:/ACS/Base/ACS.FDB;DataSource=10.121.101.113;Port=3050;Dialect=3;Charset=UTF8;Role=;";

            optionsBuilder.UseFirebird(connectionString);
            optionsBuilder.LogTo(Console.WriteLine);
            optionsBuilder.EnableSensitiveDataLogging();
            //base.OnConfiguring(optionsBuilder);
        }
    }
}
