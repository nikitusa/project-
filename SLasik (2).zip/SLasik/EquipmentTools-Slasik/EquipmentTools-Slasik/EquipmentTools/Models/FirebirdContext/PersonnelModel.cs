﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WMSLoginsAccounting.Models.TssPersonnelModel
{
    [Table("PERSONNEL")]
    public class PersonnelModel
    {
        [Key]
        [Column("PERS_ID")]
        public int PersonnelID { get; set; }

        public int? NTIMEZONE { get; set; }

        public string TIMEZONE { get; set; }

        [Column("TABELNOMER")]
        public string PersonnelNumber { get; set; }

        [Column("KLUCH")]
        public string PersonnelKey { get; set; }

        [Column("PGRUPPA")]
        public string Group { get; set; }

        public string FIO { get; set; }

        [Column("LASTNAME")]
        public string LastName { get; set; }

        [Column("FIRSTNAME")]
        public string FirstName { get; set; }

        [Column("MIDLENAME")]

        public string MidleName { get; set; }

        public string MARSRUT { get; set; }
        public string SHABLON { get; set; }

        [Column("DCREATE")]
        public string DateCreated { get; set; }

        [Column("TCREATE")]
        public string TimeCreated { get; set; }

        [Column("DOLJNOST")]
        public string Position { get; set; }

        [Column("DEPARTMENT")]
        public string Client { get; set; }

        [Column("FIRMA")]
        public string Firm { get; set; }

        [Column("PECHAT1")]
        public byte[]? QR_TABEL { get; set; }
    }
}
