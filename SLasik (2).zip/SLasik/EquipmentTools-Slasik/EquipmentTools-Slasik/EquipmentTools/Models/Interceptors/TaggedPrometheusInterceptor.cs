﻿using Microsoft.EntityFrameworkCore.Diagnostics;
using System.Data.Common;
using System.Diagnostics.Metrics;

namespace EquipmentTools.Models.Interceptors
{
    public class TaggedPrometheusInterceptor : DbCommandInterceptor
    {
        private Dictionary<string,string> tagHistogramMethods = new Dictionary<string,string>();

        private static readonly Dictionary<Meter, IEnumerable<Histogram<double>>> MeterHistograms = new Dictionary<Meter, IEnumerable<Histogram<double>>>();

        public TaggedPrometheusInterceptor()
        {
            
        }

        public override async ValueTask<DbDataReader> ReaderExecutedAsync(DbCommand command, CommandExecutedEventData eventData, DbDataReader result, CancellationToken token)
        {
            var rows = command.CommandText.Split(Environment.NewLine);

            var tag = rows.FirstOrDefault(c => c.Contains("--"))?.Replace("--", string.Empty).Trim();

            if (tag != null)
            {
                var serviceNameAndMethod = tag.Split(':');

                var serviceName = serviceNameAndMethod[0];
                var method = serviceNameAndMethod[1];

                var meter = MeterHistograms.Keys.FirstOrDefault(c => c.Name == serviceName);
                Histogram<double> histogram = null;

                if(meter == null)
                {
                    meter = new Meter(serviceName);
                }

                if(!MeterHistograms.TryGetValue(meter, out var histograms))
                {
                    histogram = meter.CreateHistogram<double>(method, "milliseconds");
                    histograms = new List<Histogram<double>>() { histogram };
                    MeterHistograms[meter] = histograms;
                }
                else
                {
                    histogram = histograms.FirstOrDefault(c=>c.Name == method);
                }

                if (histogram == null)
                {
                    histogram = meter.CreateHistogram<double>(method, "milliseconds");
                }

                histogram.Record(eventData.Duration.TotalMilliseconds);
            }

            return await base.ReaderExecutedAsync(command, eventData, result, token);
        }
    }
}
