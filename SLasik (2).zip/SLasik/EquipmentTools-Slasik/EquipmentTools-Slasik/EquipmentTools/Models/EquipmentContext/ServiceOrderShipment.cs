﻿using EquipmentTools.Data;

namespace EquipmentTools.Models.EquipmentContext
{
    public partial class ServiceOrderShipment
    {
        public long ServiceOrderShipmentId { get; set; }
        public long ShipmentGroupId { get; set; }
        public long ServiceOrderUnitsId { get; set; }
        public long ServiceStatusesId { get; set; }
        public virtual ServiceOrderUnit ServiceOrderUnit { get; set; }
        public virtual ServiceStatus ServiceStatuses { get; set; }
    }
}
