﻿using EquipmentTools.Models.EquipmentContext;

namespace EquipmentTools.Data;

public sealed class ServiceOrderShipmentGroup
{
    public long ShipmentGroupId { get; init; }
    public IReadOnlyList<long> ServiceOrderIds { get; init; } = Array.Empty<long>();
    public DateTime? FirstApplicationDate { get; init; }
    public string? StatusName { get; init; }
    public IReadOnlyList<ServiceOrderUnit> ServiceOrderUnits { get; init; } = Array.Empty<ServiceOrderUnit>();
}
