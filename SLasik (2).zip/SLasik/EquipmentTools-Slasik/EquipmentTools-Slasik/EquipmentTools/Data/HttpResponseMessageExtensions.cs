﻿using System.Text;

namespace EquipmentTools.Data
{
    public static class HttpResponseMessageExtensions
    {
        internal static async Task<string> WriteResponseToString(this HttpResponseMessage request)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append(request?.ReasonPhrase);
            sb.Append(' ');
            sb.Append($"HTTP/{request?.Version} ");
            sb.AppendLine("Headers :");

            if (request?.Headers?.Count() > 0)
            {
                foreach (var header in request?.Headers)
                {
                    sb.AppendLine($"{header.Key}: {String.Join(", ", header.Value)}");
                }
            }

            if (request.Content != null)
            {
                sb.AppendLine($"Content: \n{await request.Content.ReadAsStringAsync()}");
            }

            return sb.ToString();
        }
    }
}
