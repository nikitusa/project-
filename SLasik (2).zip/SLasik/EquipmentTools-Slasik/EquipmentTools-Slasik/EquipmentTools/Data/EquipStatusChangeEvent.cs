using EquipmentTools.Models.EquipmentContext;

namespace EquipmentTools.Data
{
    public class EquipStatusChangeEvent
    {
        public EquipStatusChange NewStatus { get; set; }
        public EquipStatusChange OldStatus { get; set; }
    }
}
