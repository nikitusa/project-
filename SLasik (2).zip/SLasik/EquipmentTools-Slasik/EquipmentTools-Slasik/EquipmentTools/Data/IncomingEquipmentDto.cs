﻿using System.Text;

namespace EquipmentTools.Data
{
    public class IncomingEquipmentDto
    {
        public int? internal_id { get; set; }
        public string? inv_number { get; set; }
        public string? serial { get; set; }
        public string? model { get; set; }
        public int? old_state { get; set; }
        public int? new_state { get; set; }
        public string? location { get; set; }
        public DateTime? changed_at { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new();

            sb.AppendLine($"ID:{internal_id}, ");
            sb.AppendLine($"Серийный номер:{serial}, ");
            sb.AppendLine($"Место:{location} ");

            return sb.ToString();
        }
    }
}
