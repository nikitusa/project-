﻿namespace EquipmentTools.Data
{
    public record GeneralEmployee
    {
        public string FIO { get; set; }
        public string PersonnelNumber { get; set; }

        public string Company { get; set; }
    };
}
