﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace EquipmentTools.Data
{
    public class ToolsIDEquipmentDTO
    {
       public record Row(int? internal_id,string? inv_number, string? serial, string? model, int old_state, int? new_state, string? location, DateTime? changed_at);
        [JsonProperty(PropertyName = "list")]
        public List<Row> ToolsIDData { get; set; }


        public int? internal_id { get; set; }
        public string? inv_number { get; set; }
        public string? serial { get; set; }
        public string? model { get; set; }
        public int old_state { get; set; }
        public int? new_state { get; set; }
        public string? location { get; set; }
        public DateTime? changed_at { get; set; }

    }
}
