﻿namespace EquipmentTools.Data
{
    public class EmployeeDto
    {
        public int EmployeeId { get; set;}
        public int PositionID { get; set;}
        public int PlatformID { get; set; }
        public int ClientID { get; set; }
    }
}
