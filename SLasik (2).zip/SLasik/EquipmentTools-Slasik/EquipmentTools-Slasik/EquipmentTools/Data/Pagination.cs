﻿using Microsoft.EntityFrameworkCore;

namespace EquipmentTools.Data
{
    public class Pagination<T>
    {
        public List<T> Items { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }
        public int PageCount { get; set; }
      
        public int TotalCount { get; set; }

        public Pagination(List<T> items, int page, int pageSize, int pageCount)
        {
            Items = items;
            Page = page;
            PageSize = pageSize;
            PageCount = pageCount;
        }
        public Pagination(List<T> items, int page, int pageSize, int pageCount, int totalCount)
        {
            Items = items;
            Page = page;
            PageSize = pageSize;
            PageCount = pageCount;
            TotalCount = totalCount;
        }

        public static async Task<Pagination<T>> CreateAsync(IQueryable<T> query, int page, int pageSize)
        {
            int totalCount = await query.CountAsync();
            var items = await query.Skip(pageSize * page).Take(pageSize).ToListAsync();
            var pageCount = 0;
            if (pageSize != 0)
            {
                
                pageCount = (int)Math.Ceiling((float)totalCount / (pageSize));
            }
            return new Pagination<T>(items,page,pageSize,pageCount, totalCount);
            
        }
    }
}
