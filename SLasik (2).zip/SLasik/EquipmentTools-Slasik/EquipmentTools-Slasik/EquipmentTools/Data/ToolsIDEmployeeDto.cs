﻿using Newtonsoft.Json;

namespace EquipmentTools.Data
{
    public class ToolsIDEmployeeDto
    {
        [JsonProperty("ext_id")]
        public string PersonnelID { get; set; }
        [JsonProperty("ext_login")]
        public string PersonnelNumber { get; set; }
        [JsonProperty("label")]
        public string BadgeKey { get; set; }

        [JsonProperty("firstname")]
        public string FirstName { get; set; }
    }
}
