﻿namespace EquipmentTools.Data
{
    public class EquipmentLoginsBlocked
    {
        public string FIO { get; set; }
        public string TabelNum { get; set; }
        public string Company { get; set; }
        public string EquipmentType { get; set; }

        public string Model { get; set; }
        public string SerialNumber { get; set; }

        public string Client { get; set; }
        public string? DateTimeTaken { get; set; }

        public string? CurrentClient { get;set; }
    }
}

