﻿using EquipmentTools.Models.EquipmentContext;

namespace EquipmentTools.Data
{
    public static class QueryableExtensions
    {
        public static IQueryable<EquipmentUnit> WithLastChanges(this IQueryable<EquipmentUnit> query)
        {
            return query.Select(c => new EquipmentUnit()
            {
                EquipmentUnitsID = c.EquipmentUnitsID,
                Client = c.Client,
                ClientID = c.ClientID,
                ClientActivity = new ClientActivity() { ClientActivityID = c.ClientActivity.ClientActivityID, Activity = c.ClientActivity.Activity, ActivityID = c.ClientActivity.ActivityID, ClientID = c.ClientActivity.ClientID, Client = c.ClientActivity.Client },
                ClientActivityID = c.ClientActivityID,
                Model = new EquipmentModel() { ModelsID = c.Model.ModelsID, Model = c.Model.Model, Type = c.Model.Type, TypeNavigation = c.Model.TypeNavigation },
                ModelID = c.ModelID,
                CreatedDate = c.CreatedDate,
                SerialNumber = c.SerialNumber,
                EquipmentTransfers = new List<EquipmentTransfer>() { c.EquipmentTransfers.OrderBy(x => x.EquipmentTransfersID).LastOrDefault() },
                EquipStatusChanges = new List<EquipStatusChange>() { c.EquipStatusChanges.OrderBy(x => x.EquipStatusChangesID).LastOrDefault() },
                ServiceOrderUnits = new List<ServiceOrderUnit>() { c.ServiceOrderUnits.OrderBy(x=>x.ServiceOrdersID).LastOrDefault(),
                    }
            });
        }
    }
}
