using EquipmentTools.Services;

namespace EquipmentTools.Data
{
    public class EventData
    {
        public EventsService.EventType EventType { get; set; }
        public HashSet<int> TargetAcitivityIDS { get; set; } = new ();
        public string TargetUser { get; set; }

        public object? EventDataValue { get; set; }
    }
}
