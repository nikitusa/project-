﻿using System.Text;

namespace EquipmentTools.Data
{
    public class ErrorDto
    {
        public string Message { get; set; }

        public HttpRequestMessage RequestMessage { get; set; }

        public HttpResponseMessage ResponseMessage { get; set; }

        public ErrorDto(string message = null, HttpRequestMessage requestMessage= null, HttpResponseMessage responseMessage = null) 
        {
            Message = message;
            RequestMessage = requestMessage;
            ResponseMessage = responseMessage;

        }

        public async Task<string> GetErrorMessage()
        {

            StringBuilder sb = new();


            sb.Append("Сообщение: ");
            sb.AppendLine(Message);


            sb.Append("```");

            if (RequestMessage != null)
            {
                sb.Append("Запрос: ");
                sb.AppendLine(await RequestMessage.WriteRequestToString());
            }

            if (ResponseMessage != null)
            {
                sb.Append("Ответ: ");
                sb.AppendLine(await ResponseMessage.WriteResponseToString());
            }

            sb.Append("```");

            //Message = sb.ToString();

            return sb.ToString();
        }
    }
}
