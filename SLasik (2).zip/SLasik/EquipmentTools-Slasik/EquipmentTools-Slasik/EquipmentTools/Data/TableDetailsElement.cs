﻿namespace EquipmentTools.Data
{
    public class TableDetailsElement<T>
    {
        public T Element { get; set; }

        public bool ShowDetails { get; set; }
    }
}
