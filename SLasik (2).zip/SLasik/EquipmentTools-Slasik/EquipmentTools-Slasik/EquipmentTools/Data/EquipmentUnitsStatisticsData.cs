﻿using EquipmentTools.Models.EquipmentContext;

namespace EquipmentTools.Data
{
    public class EquipmentUnitsStatisticsData
    {
        public record MetricCount
        {
            public string MetricItem { get; set; }
            public int Count { get; set; }
        }

        public List<MetricCount> Metrics { get; set; } = new();

        public string Metric { get; set; }

        public int Count { get; set; }

        public EquipmentModel Model { get; set; }

        public IList<EquipmentUnit> Units { get; set; }
    }
}
