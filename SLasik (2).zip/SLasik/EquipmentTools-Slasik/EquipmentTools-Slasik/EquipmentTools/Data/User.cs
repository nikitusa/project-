﻿namespace EquipmentTools.Data
{
    public class User
    {
        public string? Email { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public int EmployeeID { get; set; }
        public string? Role { get; set; }
    }
}
