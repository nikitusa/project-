using Coravel;
using EquipmentTools.BrowserTime;
using EquipmentTools.Components;
using EquipmentTools.Models.EmployeesContext;
using EquipmentTools.Models.EquipmentContext;
using EquipmentTools.Models.Interceptors;
using EquipmentTools.Schedulling;
using EquipmentTools.Services;
using EquipmentTools.Services.BackgroundQueue;
using EquipmentTools.Services.EmployeesService;
using EquipmentTools.Services.EquipmentSerices;
using EquipmentTools.Services.EquipmentServices;
using EquipmentTools.Services.HRTemplateServices;
using EquipmentTools.Services.InfoServices;
using HrTemplate.Models.HrTemplateContext;
using Keycloak.AuthServices.Authorization;
using KeycloakAuthZCaching.Plumbing.Authorization.Extensions;
using KeycloakAuthzCookieUpdate;
using KeycloakAuthzCookieUpdate.Extensions;
using KeycloakAuthzCookieUpdate.Services.Oidc;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.EntityFrameworkCore;
using MudBlazor.Services;
using NLog;
using NLog.Web;
using Npgsql;
using OpenTelemetry;
using OpenTelemetry.Exporter.Prometheus;
using OpenTelemetry.Metrics;
using Prometheus;
using WMSLoginsAccounting.Models.PersonnelFirebirdContext;
using WMSLoginsAccounting.Options;
using WMSLoginsAccounting.Policies;
using WMSLoginsAccounting.Services.PersonelDataService;

var logger = NLog.LogManager.Setup().LoadConfigurationFromAppSettings().GetCurrentClassLogger();
logger.Debug("init main");

var builder = WebApplication.CreateBuilder(args);

builder.Logging.AddOpenTelemetry(logging =>
{
    logging.IncludeFormattedMessage = true;
    logging.IncludeScopes = true;
});

var metrics = builder.Services.AddOpenTelemetry();

metrics.WithMetrics(metric =>
{
    metric.AddNpgsqlInstrumentation();
    metric.AddMeter("Microsoft.AspNetCore.Hosting");
    metric.AddMeter("Microsoft.EntityFrameworkCore");
    metric.AddMeter("EquipStatusChangesService");
    metric.AddMeter("EquipmentUnitsService");
    metric.AddPrometheusExporter();
});

var otlpEndpoint = builder.Configuration["OTEL_EXPORTER_OTLP_ENDPOINT"];

if (otlpEndpoint != null)
{
    metrics.UseOtlpExporter();
}

//builder.Logging.ClearProviders();
builder.Host.UseNLog();

builder.Services.AddDataProtection().SetApplicationName("EquipmentTools");

builder.Services.AddBrowserTimeProvider();
// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddControllers();
builder.Services.AddRazorPages();

builder.Services.AddKeycloakAuthenticationWithDefaults(c =>
{
    c.ChannelServiceName = "CookieUpdateChannel";
    c.CookieChannelOptions = new System.Threading.Channels.UnboundedChannelOptions() { SingleReader = false, SingleWriter = false };
}, oidcOptions: c => { c.BackchannelHttpHandler = new HttpClientHandler() { UseProxy = false }; });

builder.Services.AddKeycloakAuthorizationWithTokenHandler<ServerSideTokenStore>(builder.Configuration, c =>
{
    c.RefreshBeforeExpiration = new TimeSpan(0);
});

builder.Services.AddPermissionServiceWithRedis("ci-tkv-linux.fmcroc.ru:6379", instanceName: "EquipmentTools", c =>
{
    c.UseLocalCache = true;
    c.UseSlidingExpiration = false;
    c.CacheDuration = TimeSpan.FromMinutes(5);
    c.LocalCacheDuration = TimeSpan.FromMinutes(1);
});

#region �������� �����������
builder.Services.AddAuthorization()
    .AddKeycloakAuthorization()
    .AddAuthorizationBuilder()
    .AddPolicy("CanManageTransfers", c =>
    {
        c.RequireAuthenticatedUser();
        //c.RequireAssertion(c =>
        //{
        //    var position = c.User.FindFirstValue("positionid");

        //    var checkPassed = new string[] { "2", "6", "7", "11", "67", "16", "22", "24", "34", "38", "52", "59", "62", "63" }.Contains(position);

        //    if(c.User.Identity != null)
        //    {
        //        checkPassed = checkPassed || c.User.Identity.Name == "givanov";
        //    }
        //    return checkPassed;
        //});

        c.RequireProtectedResource("Transfers", "view");
    })
    .AddPolicy("CanAddEquipment", c =>
    {
        //c.RequireAssertion(c =>
        //{
        //    var position = c.User.FindFirstValue("positionid");
        //    var platform = c.User.FindFirstValue("platformid");

        //    var checkPassed = new string[] { "38", "67", "60" }.Contains(position);

        //    if (c.User.Identity != null)
        //    {
        //        checkPassed = checkPassed || c.User.Identity.Name == "givanov" || platform == "2" && position == "24";
        //    }
        //    return checkPassed;
        //});

        c.RequireProtectedResource("Equipment", "create");
    })
    .AddPolicy("CanEditReferenceTables", c =>
    {
        //c.RequireAssertion(c =>
        //{
        //    var position = c.User.FindFirstValue("positionid");
        //    var platform = c.User.FindFirstValue("platformid");

        //    var checkPassed = new string[] { "38", "67" }.Contains(position) && platform == "1";

        //    if (c.User.Identity != null)
        //    {
        //        checkPassed = checkPassed || c.User.Identity.Name == "givanov" || platform == "2" && position == "24";
        //    }
        //    return checkPassed;
        //});

        c.RequireProtectedResource("Service", "view");
    })
    .AddPolicy("CanServiceRequests", c =>
    {
        //c.RequireAssertion(c =>
        //{
        //    var position = c.User.FindFirstValue("positionid");
        //    var platform = c.User.FindFirstValue("platformid");

        //    var checkPassed = new string[] { "38", "67" }.Contains(position) && platform == "1";

        //    if (c.User.Identity != null)
        //    {
        //        checkPassed = checkPassed || c.User.Identity.Name == "givanov" || platform == "2" && position == "24";
        //    }
        //    return checkPassed;
        //});

        c.RequireProtectedResource("ServiceOrders", "view");
    })
    .AddPolicy("CanViewEquipmentListing", c =>
    {
        //c.RequireAssertion(c =>
        //{
        //    var position = c.User.FindFirstValue("positionid");

        //    var checkPassed = new string[] { "38", "2", "6", "7", "11", "67", "10", "16", "22", "24", "31", "34", "49", "60", "62", "63" }.Contains(position);

        //    if (c.User.Identity != null)
        //    {
        //        checkPassed = checkPassed || c.User.Identity.Name == "givanov" || c.User.Identity.Name == "nsnigirev";
        //    }
        //    return checkPassed;
        //});

        c.RequireProtectedResource("Equipment", "view");
    })
    .AddPolicy("CanViewHistory", c =>
    {
        //c.RequireAssertion(c =>
        //{
        //    var position = c.User.FindFirstValue("positionid");

        //    var checkPassed = new string[] { "38", "2", "6", "7", "11", "67", "16", "22", "24", "34", "49", "62", "63" }.Contains(position);

        //    if (c.User.Identity != null)
        //    {
        //        checkPassed = checkPassed || c.User.Identity.Name == "givanov" || c.User.Identity.Name == "nsnigirev";
        //    }
        //    return checkPassed;
        //});

        c.RequireProtectedResource("History", "view");
    })
    .AddPolicy("CanChangeEquipmentStatus", c =>
    {
        //c.RequireAssertion(c =>
        //{
        //    var position = c.User.FindFirstValue("positionid");

        //    var checkPassed = new string[] { "38", "2", "8", "6", "7", "11", "67", "16", "22", "24", "34", "62", "63" }.Contains(position);

        //    if (c.User.Identity != null)
        //    {
        //        checkPassed = checkPassed || c.User.Identity.Name == "givanov";
        //    }
        //    return checkPassed;
        //});

        c.RequireProtectedResource("Status", "edit");
    })
    .AddPolicy("CanSwitchClientActivity", c =>
    {
        //c.RequireAssertion(c =>
        //{
        //    var employeeId = c.User.FindFirstValue("employeeid");
        //    var positionId = c.User.FindFirstValue("positionid");
        //    var platformId = c.User.FindFirstValue("platformid");

        //    if (new string[] { "38", "67" }.Contains(positionId) && platformId == "1" || employeeId == "537" || c.User.Identity.Name == "givanov" || platformId == "2" && positionId == "24") return true;

        //    return false;
        //});

        c.RequireProtectedResource("Equipment", "edit");
    })
    .AddPolicy("CanManageInventories", c =>
    {
        //c.RequireAssertion(c =>
        //{
        //    var position = c.User.FindFirstValue("positionid");
        //    var platform = c.User.FindFirstValue("platformid");

        //    var checkPassed = new string[] { "38", "67" }.Contains(position) && platform == "1";

        //    if (c.User.Identity != null)
        //    {
        //        checkPassed = checkPassed || c.User.Identity.Name == "givanov" || platform == "2" && position == "24";
        //    }
        //    return checkPassed;
        //});

        c.RequireProtectedResource("Inventory", "view");
    });

#endregion

builder.Services.AddCachingDecorator();

//builder.Services.AddDbContext<EquipmentContext>(
//options => options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")))
builder.Services.AddDbContextFactory<EquipmentContext>(options =>
{
    string connectionString = string.Empty;

    if (!builder.Environment.IsDevelopment())
    {
        connectionString = builder.Configuration.GetConnectionString("DevEquipmentConnection");
    }
    else
    {
        connectionString = builder.Configuration.GetConnectionString("ProdEquipmentConnection");
    }

    options.UseNpgsql(connectionString, conf => conf.CommandTimeout(10)).AddInterceptors(new TaggedPrometheusInterceptor());
}
);

builder.Services.AddDbContextFactory<EmployeesContext>(
       options => options.UseNpgsql(builder.Configuration.GetConnectionString("LoginsDataConnection"), conf => conf.CommandTimeout(10)));
builder.Services.AddDbContextFactory<HrTemplateContext>(
       options => options.UseSqlServer(builder.Configuration.GetConnectionString("HRTemplateConnection"), conf => conf.CommandTimeout(10)));
builder.Services.AddDbContextFactory<PersonnelFirebirdContext>();
builder.Services.AddHttpContextAccessor();

builder.Services.AddHttpClient("IdentityApiClient", x => x.BaseAddress = new Uri("http://ci_tkv.fmcroc.ru:7777")).AddHttpMessageHandler<TokenDelegatingHandler>();
builder.Services.AddHttpClient("SubmissionsApiClient", x => x.BaseAddress = new Uri("http://ci_tkv.fmcroc.ru:5121")).AddHttpMessageHandler<TokenDelegatingHandler>();
builder.Services.AddHttpClient("ToolsIDApiClient", x => x.BaseAddress = new Uri("http://90.156.205.169")).AddHttpMessageHandler<ToolsIDTokenDelegatingHandler>();
builder.Services.AddHttpClient("ErrorNotifierClient", x => x.BaseAddress = new Uri("https://n8n.fmlogistic.com/webhook/"));
builder.Services.AddScheduler();

builder.Services.AddMudServices();

builder.Services.Configure<DatabaseReconnectSettings>(builder.Configuration.GetSection("DatabaseReconnectSettings"));
builder.Services.AddSingleton<IDatabaseRetryService, DatabaseRetryService>();

builder.Services.AddSingleton<PlatformService>();
builder.Services.AddSingleton<EmployeesService>();
builder.Services.AddSingleton<EquipmentUnitsService>();
builder.Services.AddSingleton<EquipStatusService>();
builder.Services.AddSingleton<EquipStatusChangesService>();
builder.Services.AddSingleton<ClientService>();
builder.Services.AddSingleton<DamageTypesSerice>();
builder.Services.AddSingleton<EmployeesTSSService>();
builder.Services.AddSingleton<EquipmentTransfersService>();
builder.Services.AddSingleton<EventsService>();
builder.Services.AddSingleton<ServiceOrderService>();
builder.Services.AddSingleton<EquipmentTypesService>();
builder.Services.AddSingleton<EquipmentModelService>();
builder.Services.AddSingleton<ActivityService>();
builder.Services.AddSingleton<ClientActivityService>();
builder.Services.AddSingleton<AllEmployeesDBService>();
builder.Services.AddSingleton<ToolsIDService>();
builder.Services.AddSingleton<BadgeBlockingService>();
builder.Services.AddSingleton<PersonelService>();
builder.Services.AddSingleton<InventoriesService>();
builder.Services.AddSingleton<InventoryMembersService>();
builder.Services.AddSingleton<InventoryUnitsService>();
builder.Services.AddSingleton<ServiceStatusService>();
builder.Services.AddSingleton<ServiceOrdersStatusesService>();
builder.Services.AddSingleton<EmployeeBadgesService>();
builder.Services.AddSingleton<ServiceOrderShipmentService>();

builder.Services.AddScoped<TokenDelegatingHandler>();
builder.Services.AddScoped<ToolsIDTokenDelegatingHandler>();
builder.Services.AddScoped<UserService>();
builder.Services.AddScoped<JwtService>();

builder.Services.AddTransient<SetToolsIDStatusInvocable>();
builder.Services.AddTransient<LoginsBlockedGoogleInvocable>();

builder.Services.AddSingleton<IBackgroundTaskQueue>(ctx =>
{
    if (!int.TryParse(builder.Configuration["QueueCapacity"], out var queueCapacity))
        queueCapacity = 100;
    return new BackgroundTaskQueue(queueCapacity);
});

builder.Services.AddHostedService<QueuedHostedService>();

var app = builder.Build();

app.UseForwardedHeaders(new ForwardedHeadersOptions
{
    ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto
});

//app.Services.UseScheduler(s =>
//{
//    s.Schedule<LoginsBlockedGoogleInvocable>()
//    .Cron("*/1 * * * *")
//    .Zoned(TimeZoneInfo.Local)
//    .PreventOverlapping("loginsBlockedExport")
//    .RunOnceAtStart();
//    //s.Schedule<SetToolsIDStatusInvocable>()
//    ////.Cron("*/2 * * * *")
//    //.Cron("* * * * 2100")
//    //.Zoned(TimeZoneInfo.Local)
//    //.RunOnceAtStart();
//});

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
}

app.UseStaticFiles();

app.MapControllers();

app.UseRouting();

app.UseAntiforgery();

app.MapMetrics();

app.UseAuthentication();
app.UseAuthorization();

if (app.Environment.IsDevelopment())
{
    app.RegisterOidcAuthenticationEndpoints("http://localhost:6060");
}
else
{
    app.RegisterOidcAuthenticationEndpoints("https://equipment-tools.fmcroc.ru");
}

app.RegisterCookieUpdateEndpoint();

app.MapRazorPages();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
