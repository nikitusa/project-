﻿using EquipmentTools.Models.EquipmentContext;
using Microsoft.EntityFrameworkCore;

namespace EquipmentTools.Services.EquipmentServices;

public class ServiceOrderShipmentService
{
    public const long CreatedServiceStatusId = 1;

    private readonly IDbContextFactory<EquipmentContext> dbContextFactory;

    public ServiceOrderShipmentService(IDbContextFactory<EquipmentContext> dbContextFactory)
    {
        this.dbContextFactory = dbContextFactory;
    }


    public async Task<List<ServiceOrder>> GetCreatedOrdersAsync()
    {
        await using var context = await dbContextFactory.CreateDbContextAsync();

        var groupedUnitIds = context.ServiceOrderShipments
            .Select(shipment => shipment.ServiceOrderUnitsId);

        var orders = await context.ServiceOrders
            .AsNoTracking()
            .Include(order => order.ServiceOrderStatuses)
            .Include(order => order.ServiceOrderUnits)
                .ThenInclude(unit => unit.Unit)
                    .ThenInclude(unit => unit.Model)
                        .ThenInclude(model => model.TypeNavigation)
            .Include(order => order.ServiceOrderUnits)
                .ThenInclude(unit => unit.DamageTypes)
            .Where(order => order.ServiceOrderUnits
                .All(unit => !groupedUnitIds.Contains(unit.ServiceOrderUnitsID)))
            .OrderByDescending(order => order.ServiceOrdersID)
            .ToListAsync();

        return orders
            .Where(order => order.ServiceOrderStatuses
                .OrderByDescending(status => status.ServiceOrderStatusesID)
                .FirstOrDefault()?.StatusID == CreatedServiceStatusId)
            .ToList();
    }


    public async Task<long> CreateShipmentAsync(IEnumerable<long> serviceOrderIds)
    {
        var orderIds = serviceOrderIds.Distinct().ToList();
        if (orderIds.Count < 2)
            throw new InvalidOperationException("Выберите минимум две заявки.");

        await using var context = await dbContextFactory.CreateDbContextAsync();
        

        var orders = await context.ServiceOrders
            .Where(order => orderIds.Contains(order.ServiceOrdersID))
            .Include(order => order.ServiceOrderStatuses)
            .Include(order => order.ServiceOrderUnits)
            .ToListAsync();

        if (orders.Count != orderIds.Count)
            throw new InvalidOperationException("Часть выбранных заявок больше не существует.");

        if (orders.Any(order => order.ServiceOrderStatuses
            .OrderByDescending(status => status.ServiceOrderStatusesID)
            .FirstOrDefault()?.StatusID != CreatedServiceStatusId))
        {
            throw new InvalidOperationException("Объединять можно только заявки с актуальным статусом «Создано».");
        }

        var serviceOrderUnitIds = orders
            .SelectMany(order => order.ServiceOrderUnits)
            .Select(unit => unit.ServiceOrderUnitsID)
            .ToList();

        if (serviceOrderUnitIds.Count == 0)
            throw new InvalidOperationException("В выбранных заявках нет оборудования.");

        var alreadyGrouped = await context.ServiceOrderShipments
            .AnyAsync(shipment => serviceOrderUnitIds.Contains(shipment.ServiceOrderUnitsId));

        if (alreadyGrouped)
            throw new InvalidOperationException("Одна или несколько единиц оборудования уже входят в объединённую заявку.");

        // A group is represented by rows in one table. First save generates an identity
        // for the first row; that value becomes the common identifier for all rows.
        var shipments = serviceOrderUnitIds.Select(unitId => new ServiceOrderShipment
        {
            ShipmentGroupId = 0,
            ServiceOrderUnitsId = unitId,
            ServiceStatusesId = CreatedServiceStatusId
        }).ToList();

        context.ServiceOrderShipments.AddRange(shipments);
        await context.SaveChangesAsync();

        var shipmentGroupId = shipments[0].ServiceOrderShipmentId;
        foreach (var shipment in shipments)
            shipment.ShipmentGroupId = shipmentGroupId;

        await context.SaveChangesAsync();
        
        return shipmentGroupId;
    }
    

}